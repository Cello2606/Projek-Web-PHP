<?php
include 'includes/config.php';
$data = mysqli_query($conn, "
SELECT * FROM dosen
");
?>
<div class="card mb-4">
    <div class="card-header">Profil Singkat Dosen</div>
    <div class="card-body">
    <?php while ($d = mysqli_fetch_assoc($data)) { ?>
    <p class="card-text" style="text-align: justify; font-size: 15px;">
        Salah satu dosen yang ada di lingkungan fakultas adalah <b><?= $d['dosen_Nama']; ?></b>.  
        Beliau memiliki NIDN <b><?= $d['dosen_NIDN']; ?></b> serta terdaftar dengan NIK <b><?= $d['dosen_NIK']; ?></b>.  
        Berdasarkan informasi yang tersedia, dosen ini dikenal dengan karakteristik sebagai berikut: 
        <i><?= $d['dosen_Ket']; ?></i>.  
        Profil ini memberikan gambaran singkat mengenai peran dan identitas beliau dalam aktivitas akademik.
    </p>
    <hr>
    <?php } ?>
    </div>
</div>
