<?php include 'includes/config.php'; ?>

<div class="card" style="width: 18rem;">
  <img src="images/muka.jpeg" class="card-img-top">
  <div class="card-body">
    <h5 class="card-title">Profil Diri Saya</h5>
    <p class="card-text">Nama  :Kenny Prasetya Therry</p>
    <p class="card-text">NIM   : 825240130</p>
    <p class="card-text">Kelas : SI C</p>
  </div>
</div>