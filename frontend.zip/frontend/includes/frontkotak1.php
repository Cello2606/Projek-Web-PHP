<?php
include 'includes/config.php';

$data = mysqli_query($conn, "
SELECT bimbinganskripsi.mhs_NPM, mahasiswa.mhs_Nama, dosen.dosen_Nama, bimbinganskripsi.TGL_bimbingan, bimbinganskripsi.ISI_bimbingan, bimbinganskripsi.dokumen
FROM bimbinganskripsi
JOIN mahasiswa ON mahasiswa.mhs_NPM = bimbinganskripsi.mhs_NPM
JOIN dosen ON dosen.dosen_NIDN = bimbinganskripsi.dosen_NIDN
ORDER BY bimbinganskripsi.TGL_bimbingan DESC
");
?>

<div class="card mb-4">
    <div class="card-header bg-dark text-white">Data Bimbingan Skripsi</div>
    <div class="card-body">
        <div class="table-responsive">
        <table class="table table-bordered table-striped w-100">
            <thead class="table-success">
                <tr>
                    <th>NPM</th>
                    <th>Nama</th>
                    <th>Dosen</th>
                    <th>Tanggal</th>
                    <th>Isi</th>
                    <th>Dokumen</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($b = mysqli_fetch_assoc($data)) { ?>
                <tr>
                    <td><?= $b['mhs_NPM']; ?></td>
                    <td><?= $b['mhs_Nama']; ?></td>
                    <td><?= $b['dosen_Nama']; ?></td>
                    <td><?= $b['TGL_bimbingan']; ?></td>
                    <td><?= $b['ISI_bimbingan']; ?></td>
                    <td>
                        <?php if ($b['dokumen'] == "") { ?>
                        <?php } else { ?>
                        <a href="../admin/images/<?= $b['dokumen']; ?>" class="btn btn-sm btn-primary" target="_blank">PDF</a>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
    </div>
</div>