<?php 
include 'includes/config.php';

$query = mysqli_query($conn, "
    SELECT 
        penasihat.mhs_NPM,
        penasihat.dosen_NIDN,
        penasihat.penasihat_FILE,
        penasihat.penasihat_KET,
        mahasiswa.mhs_Nama,
        dosen.dosen_Nama
    FROM penasihat
    JOIN mahasiswa ON mahasiswa.mhs_NPM = penasihat.mhs_NPM
    JOIN dosen ON dosen.dosen_NIDN = penasihat.dosen_NIDN
");

while ($row = mysqli_fetch_assoc($query)) {
    $gambar = $row['penasihat_FILE'] 
                ? "../admin/images/" . $row['penasihat_FILE'] 
                : "images/noimages.jpeg";
?>
    <div class="col-md-8 mb-3">
        <div class="d-flex">
            <div class="flex-shrink-0">
                <img src="<?php echo $gambar; ?>" class="img-fluid rounded" alt="dokumen" style="width:150px; height:150px;">
            </div>

            <div class="flex-grow-1 ms-3">
                <h5><?php echo $row['mhs_Nama'] . " (" . $row['mhs_NPM'] . ")"; ?></h5>
                
                <p>Penasihat: <b><?php echo $row['dosen_Nama']; ?></b> (<?php echo $row['dosen_NIDN']; ?>)</p>

                <p>Keterangan: <?php echo $row['penasihat_KET']; ?></p>
            </div>
        </div>
    </div>
<?php } ?>
