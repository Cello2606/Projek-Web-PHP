<?php include 'includes/config.php';
$query = mysqli_query($conn, "
SELECT *
FROM pesertaskripsi JOIN mahasiswa ON mahasiswa.mhs_NPM = pesertaskripsi.mhs_NPM
");
while ($row = mysqli_fetch_assoc($query)) {
$gambar = $row['peserta_DOKUMEN'] ? "../admin/images/" . $row['peserta_DOKUMEN'] : "images/noimages.jpeg";?>
    <div class="col-md-8 mb-3">
        <div class="d-flex">
            <div class="flex-shrink-0">
            <img src="<?php echo $gambar; ?>" class="img-fluid rounded" alt="dokumen" style="width:150px; height:auto;">
            </div>
            <div class="flex-grow-1 ms-3">
                <h5><?php echo $row['mhs_Nama'] . " (" . $row['mhs_NPM'] . ")"; ?></h5>
                <p>Judul Skripsi: <?php echo $row['peserta_JUDUL']; ?></p>
                <p>Semester: <?php echo $row['peserta_SEMT']; ?> | Tahun Akademik: <?php echo $row['peserta_THAKD']; ?></p>
                <p>Tanggal Daftar: <?php echo $row['peserta_TGLDAFTAR']; ?></p>
            </div>
        </div>
    </div>
<?php } ?>