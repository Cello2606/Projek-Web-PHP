<?php
include 'includes/config.php';

$data = mysqli_query($conn, "
SELECT pesertaskripsi.mhs_NPM, mahasiswa.mhs_Nama, pesertaskripsi.peserta_SEMT, pesertaskripsi.peserta_THAKD, pesertaskripsi.peserta_TGLDAFTAR, 
pesertaskripsi.peserta_JUDUL, pesertaskripsi.peserta_DOKUMEN
FROM pesertaskripsi
JOIN mahasiswa ON mahasiswa.mhs_NPM = pesertaskripsi.mhs_NPM
ORDER BY pesertaskripsi.peserta_TGLDAFTAR DESC
");
?>

<div class="card mb-4">
    <div class="card-header bg-dark text-white">Data Peserta Skripsi</div>
    <div class="card-body">
        <div class="table-responsive">
        <table class="table table-bordered table-striped w-100">
            <thead class="table-success">
                <tr>
                    <th>NPM</th>
                    <th>Nama</th>
                    <th>Semester</th>
                    <th>Tahun Akd</th>
                    <th>Tanggal Daftar</th>
                    <th>Judul</th>
                    <th>Dokumen</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($b = mysqli_fetch_assoc($data)) { ?>
                <tr>
                    <td><?= $b['mhs_NPM']; ?></td>
                    <td><?= $b['mhs_Nama']; ?></td>
                    <td><?= $b['peserta_SEMT']; ?></td>
                    <td><?= $b['peserta_THAKD']; ?></td>
                    <td><?= $b['peserta_TGLDAFTAR']; ?></td>
                    <td><?= $b['peserta_JUDUL']; ?></td>
                    <td>
                        <?php if ($b['peserta_DOKUMEN'] == "") { ?>
                        <?php } else { ?>
                        <a href="../admin/images/<?= $b['peserta_DOKUMEN']; ?>" class="btn btn-sm btn-primary" target="_blank">Lihat</a>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
    </div>
</div>
