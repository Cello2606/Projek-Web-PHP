<?php
include 'includes/config.php';

$data = mysqli_query($conn, "
SELECT jadwalskripsi.mhs_NPM, mahasiswa.mhs_Nama, jadwalskripsi.waktu_SKRIPSI, jadwalskripsi.tanggal_SKRIPSI, jadwalskripsi.tempat_SKRIPSI, ujianskripsi.TGL_ujian,
ujianskripsi.foto_UJIAN
FROM jadwalskripsi JOIN mahasiswa ON mahasiswa.mhs_NPM = jadwalskripsi.mhs_NPM
LEFT JOIN ujianskripsi ON ujianskripsi.mhs_NPM = jadwalskripsi.mhs_NPM
");
?>

<div class="card mb-4">
    <div class="card-header bg-dark text-white">Data Gabungan Skripsi</div>
    <div class="card-body">
        <div class="table-responsive">
        <table class="table table-bordered table-striped w-100">
            <thead class="table-success">
                <tr>
                    <th>NPM</th>
                    <th>Nama</th>
                    <th>Waktu Skripsi</th>
                    <th>Tanggal Skripsi</th>
                    <th>Tempat Skripsi</th>
                    <th>Tanggal Ujian</th>
                    <th>Foto Ujian</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($b = mysqli_fetch_assoc($data)) { ?>
                <tr>
                    <td><?= $b['mhs_NPM']; ?></td>
                    <td><?= $b['mhs_Nama']; ?></td>
                    <td><?= $b['waktu_SKRIPSI']; ?></td>
                    <td><?= $b['tanggal_SKRIPSI']; ?></td>
                    <td><?= $b['tempat_SKRIPSI']; ?></td>
                    <td><?= $b['TGL_ujian']; ?></td>
                    <td>
                        <?php if ($b['foto_UJIAN'] == "") { ?>
                        <?php } else { ?>
                        <a href="../admin/images/<?= $b['foto_UJIAN']; ?>" class="btn btn-sm btn-primary" target="_blank">Lihat</a>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
    </div>
</div>
