<?php
include 'includes/config.php';

// Ambil data dari tabel mahasiswa
$data = mysqli_query($conn, "SELECT mhs_NPM, mhs_Nama, mhs_Alamat, mhs_DOB, mhs_Ket FROM mahasiswa ORDER BY mhs_NPM ASC");
?>

<div class="card mb-4">
    <div class="card-header">Deskripsi Data Mahasiswa</div>
    <div class="card-body">

    <?php while ($m = mysqli_fetch_assoc($data)) { ?>

        <p style="text-align: justify; line-height: 1.7;">
            Mahasiswa dengan NPM <b><?= $m['mhs_NPM']; ?></b> bernama 
            <b><?= $m['mhs_Nama']; ?></b> tercatat tinggal di alamat 
            <b><?= $m['mhs_Alamat']; ?></b>. Berdasarkan data akademik, mahasiswa ini lahir pada 
            tanggal <b><?= $m['mhs_DOB']; ?></b>.  
            Keterangan tambahan terkait mahasiswa ini adalah: 
            <b><?= $m['mhs_Ket']; ?></b>.
        </p>

        <hr>

    <?php } ?>

    </div>
</div>
