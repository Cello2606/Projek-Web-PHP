<h1 class="mt-5 mb-5 text-center">Galeri Foto</h1>
<div class="galerifoto row g-4">
<?php
include 'includes/config.php';
$kueri = mysqli_query($conn, "
SELECT ujianskripsi.foto_ujian, ujianskripsi.mhs_NPM, pesertaskripsi.peserta_JUDUL
FROM ujianskripsi INNER JOIN pesertaskripsi ON pesertaskripsi.mhs_NPM = ujianskripsi.mhs_NPM
");
while ($row = mysqli_fetch_assoc($kueri)) {
    $gambarSkripsi = !empty($row['foto_ujian']) ? "../admin/images/" . $row['foto_ujian'] : "../admin/images/noimages.jpeg";
?>
    <figure class="col-lg-4 col-sm-6 col-xs-12">
        <div class="flex-shrink-0">
            <img src="<?php echo $gambarSkripsi; ?>" 
                class="img-fluid rounded" 
                style="width:350px; height:200px;"
            >
        </div>
        <figcaption class="figure-caption" style="font-size: 30px;">
            <strong><?php echo $row['peserta_JUDUL']; ?></strong>
        </figcaption>
    </figure>
<?php
}
?>
</div>
