<?php include 'includes/config.php';

$query = mysqli_query($conn, "
SELECT ujianskripsi.mhs_NPM, ujianskripsi.TGL_ujian, ujianskripsi.WKT_ujian, mahasiswa.mhs_Nama, dosen.dosen_Nama
FROM ujianskripsi JOIN mahasiswa ON mahasiswa.mhs_NPM = ujianskripsi.mhs_NPM
JOIN bimbinganskripsi ON bimbinganskripsi.mhs_NPM = ujianskripsi.mhs_NPM
JOIN dosen ON dosen.dosen_NIDN = bimbinganskripsi.dosen_NIDN
");
?>
<div class="list-group">
    <?php while($row = mysqli_fetch_assoc($query)) { ?>
    <a href="#" class="list-group-item list-group-item-action active" aria-current="true">
    <div class="d-flex w-100 justify-content-between">
      <h5 class="mb-1"><?php echo $row['mhs_NPM']; ?></h5>
      <small><?php echo $row['TGL_ujian'] . " " . $row['WKT_ujian']; ?></small>
    </div>
    <p class="mb-1"><?php echo $row['mhs_Nama']; ?></p>
    <small>Pembimbing: <?php echo $row['dosen_Nama']; ?></small>
  </a>
  <?php } ?>
</div>