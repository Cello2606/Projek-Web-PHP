<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
    <?php include "includes/frontmenu.php";?>
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/zx6r2.jpg" class="d-block w-100" alt="No Picture">
    </div>
    <div class="carousel-item">
      <img src="images/zx6r2.jpg" class="d-block w-100" alt="No Picture">
    </div>
    <div class="carousel-item">
      <img src="images/zx6r2.jpg" class="d-block w-100" alt="No Picture">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

    <div class="container">

    <div class="row atas mt-5">

    <!-- KIRI -->
    <div class="col-sm-8">
        <?php include "includes/front1.php"; ?>
    </div>

    <!-- KANAN -->
    <div class="col-sm-4">
        <?php include "includes/front2.php"; ?>
    </div>

</div>
<?php include "includes/gallery.php"; ?>
    <div class="row tengah mt-5">
        <div class="col-md-4">
          <?php include "includes/frontkotak1.php"; ?>
</div>
        <div class="col-md-4">
            <?php include "includes/frontkotak2.php"; ?>
        </div>
        <div class="col-md-4">
            <?php include "includes/frontkotak3.php"; ?>
        </div>
    </div>

    <div class="row atas mt-5">
        <div class="col-sm-4">
            <?php include "includes/frontbawah1.php"; ?>
          </div>
        <div class="col-sm-8">
            <?php include "includes/frontbawah2.php"; ?>
            <div class="row">
    <div class="col-sm-6">
        <?php include "includes/frontbawahbanget1.php"; ?>
    </div>
    <div class="col-sm-6">
    <?php include "includes/frontbawahbanget2.php"; ?>
</div>  
        </div>
    </div>

    </div>




</body>
<script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
</html>