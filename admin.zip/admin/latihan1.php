<?php
echo "WEBDEV Menyedihkan" , "S <3 K";
echo "<br>";
print "WEBDEV Menyedihkan" , "S <3 K";

//gabisa angka 12345

$teks = "Belajar PHP";
$teks2 = "WEBDEV";
$angka1 = 30;
$angka2 = 12;
$jumlahangka = $angka1 - $angka2;
$gabungan = "$teks + $teks2";

echo "Saya sedih $teks !";
echo "<br>";
echo "Saya Senang" , $teks , "! ";
echo "<br>";
echo "Jumlah angka = $jumlahangka ";
echo "<br>";
echo "Gabungannya adalah = $gabungan";

//variable lokal
function
Test2(){
    $B = 10;
    echo "Variable Lokal ada dalam fungsi = $B";
}
Test2(){
    echo "<br>";
    echo "Variable Lokal ada dalam fungsi = $B";
}

?>