<?php

include "includes/config.php"; 


if(isset($_GET['hapusdosen']))
{
  
    $NPM = $_GET["hapusdosen"]; 
    

    mysqli_query($conn, "DELETE FROM dosen WHERE mhs_NPM = '$NPM'");
    
    
    echo "<script>alert('DATA BERHASIL DIHAPUS');";
    echo "document.location='inputdosen.php'</script>";
}
?>