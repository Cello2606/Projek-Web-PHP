<?php
ob_start();
session_start();
if (!isset($_SESSION['useremail'])) {
    header("location:login.php");
    exit;
}

include("includes/config.php");

// ====== TAMBAH DATA ======
if (isset($_POST['Simpan'])) {
    $mhs_NPM            = $_POST['npmMHS'];
    $peserta_SEMT       = $_POST['semester'];
    $peserta_THAKD      = $_POST['thakd'];
    $peserta_TGLDAFTAR  = $_POST['tgl_daftar'];
    $peserta_JUDUL      = $_POST['judul'];
    $peserta_DOKUMEN    = $_FILES['dokumen']['name'];
    $dokumen_tmp        = $_FILES['dokumen']['tmp_name'];

    if ($peserta_DOKUMEN != "") {
        move_uploaded_file($dokumen_tmp, 'images/' . $peserta_DOKUMEN);
    }

    $sql = "INSERT INTO pesertaskripsi 
            (mhs_NPM, peserta_SEMT, peserta_THAKD, peserta_TGLDAFTAR, peserta_JUDUL, peserta_DOKUMEN)
            VALUES ('$mhs_NPM', '$peserta_SEMT', '$peserta_THAKD', '$peserta_TGLDAFTAR', '$peserta_JUDUL', '$peserta_DOKUMEN')";
    mysqli_query($conn, $sql);
    header("location:inputpesertaskripsi.php");
    exit;
}

// ====== HAPUS DATA ======
if (isset($_GET['hapus'])) {
    $hapus = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM pesertaskripsi WHERE mhs_NPM='$hapus'");
    header("location:inputpesertaskripsi.php");
    exit;
}

// ====== EDIT DATA ======
if (isset($_POST['ubah'])) {
    $mhs_NPM           = $_POST['npmMHS'];
    $peserta_SEMT      = $_POST['semester'];
    $peserta_THAKD     = $_POST['thakd'];
    $peserta_TGLDAFTAR = $_POST['tgl_daftar'];
    $peserta_JUDUL     = $_POST['judul'];
    $peserta_DOKUMEN   = $_FILES['dokumen']['name'];
    $dokumen_tmp       = $_FILES['dokumen']['tmp_name'];

    if ($peserta_DOKUMEN != "") {
        move_uploaded_file($dokumen_tmp, 'images/' . $peserta_DOKUMEN);
        $update = "UPDATE pesertaskripsi 
                   SET peserta_SEMT='$peserta_SEMT', peserta_THAKD='$peserta_THAKD', peserta_TGLDAFTAR='$peserta_TGLDAFTAR',
                       peserta_JUDUL='$peserta_JUDUL', peserta_DOKUMEN='$peserta_DOKUMEN'
                   WHERE mhs_NPM='$mhs_NPM'";
    } else {
        $update = "UPDATE pesertaskripsi 
                   SET peserta_SEMT='$peserta_SEMT', peserta_THAKD='$peserta_THAKD', peserta_TGLDAFTAR='$peserta_TGLDAFTAR',
                       peserta_JUDUL='$peserta_JUDUL'
                   WHERE mhs_NPM='$mhs_NPM'";
    }

    mysqli_query($conn, $update);
    header("location:inputpesertaskripsi.php");
    exit;
}

// ====== TAMPILKAN DATA ======
$datamhs = mysqli_query($conn, "SELECT * FROM mahasiswa");

// ====== PENCARIAN ======
if (isset($_POST["kirim"])) {
    $search = $_POST["search"];
    $query = mysqli_query($conn, "
        SELECT * FROM pesertaskripsi 
        JOIN mahasiswa ON pesertaskripsi.mhs_NPM = mahasiswa.mhs_NPM
        WHERE mahasiswa.mhs_NPM LIKE '%$search%' OR mahasiswa.mhs_Nama LIKE '%$search%'
    ");
} else {
    $query = mysqli_query($conn, "
        SELECT * FROM pesertaskripsi 
        JOIN mahasiswa ON pesertaskripsi.mhs_NPM = mahasiswa.mhs_NPM
    ");
}
?>

<!DOCTYPE html>
<html>
    <?php include "bagiankode/head.php"; ?>
    <!-- Tambahan CSS untuk Select2 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/css/select2.min.css">

<body class="sb-nav-fixed">
<?php include "bagiankode/menunav.php"; ?>

<div id="layoutSidenav">
    <?php include "bagiankode/menu.php"; ?>

    <div id="layoutSidenav_content">
    <main>
    <div class="container-fluid px-4">

        <h1 class="mt-4">Input Peserta Skripsi</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Peserta Skripsi</li>
        </ol>

        <div class="row">
        <div class="col-12">
            <h3 class="mt-4 mb-3 text-center">Formulir Pendaftaran Skripsi</h3>

            <!-- ===== FORM INPUT ===== -->
            <form method="POST" enctype="multipart/form-data">
                <div class="row mb-3">
                    <label for="npmMHS" class="col-sm-2 col-form-label">NPM Mahasiswa</label>
                    <div class="col-sm-10">
                        <select class="form-control" id="npmMHS" name="npmMHS" required>
                            <option value="">Pilih Mahasiswa</option>
                            <?php while ($row = mysqli_fetch_array($datamhs)) { ?>
                            <option value="<?php echo $row["mhs_NPM"]; ?>">
                                <?php echo $row["mhs_NPM"] . " - " . $row["mhs_Nama"]; ?>
                            </option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Semester</label>
                    <div class="col-sm-10">
                        <select class="form-control" name="semester" required>
                            <option value="">Pilih Semester</option>
                            <option value="Ganjil">Ganjil</option>
                            <option value="Genap">Genap</option>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Tahun Akademik</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="thakd" placeholder="contoh: 2024/2025" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Tanggal Daftar</label>
                    <div class="col-sm-10">
                        <input type="date" class="form-control" name="tgl_daftar" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Judul Skripsi</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="judul" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Dokumen (Gambar)</label>
                    <div class="col-sm-10">
                        <input type="file" class="form-control" name="dokumen">
                    </div>
                </div>

                <div class="text-center mb-4">
                    <input type="submit" class="btn btn-success" name="Simpan" value="Simpan">
                    <input type="reset" class="btn btn-danger" value="Batal">
                </div>
            </form>

            <!-- ===== FORM SEARCH ===== -->
            <form method="POST" class="mb-3">
                <div class="row">
                    <label class="col-sm-2 col-form-label">Cari Mahasiswa</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" name="search" placeholder="Cari berdasarkan NPM atau nama">
                    </div>
                    <div class="col-sm-2">
                        <input type="submit" name="kirim" value="Cari" class="btn btn-primary w-100">
                    </div>
                </div>
            </form>

            <!-- ===== TABEL DATA ===== -->
            <table class="table table-striped table-success table-hover">
                <tr class="info text-center">
                    <th>NPM</th>
                    <th>Nama Mahasiswa</th>
                    <th>Semester</th>
                    <th>Tahun Akd.</th>
                    <th>Tgl. Daftar</th>
                    <th>Judul</th>
                    <th>Dokumen</th>
                    <th colspan="2">Aksi</th>
                </tr>

                <?php while ($row = mysqli_fetch_array($query)) { ?>
                <tr class="text-center">
                    <td><?php echo $row['mhs_NPM']; ?></td>
                    <td><?php echo $row['mhs_Nama']; ?></td>
                    <td><?php echo $row['peserta_SEMT']; ?></td>
                    <td><?php echo $row['peserta_THAKD']; ?></td>
                    <td><?php echo $row['peserta_TGLDAFTAR']; ?></td>
                    <td><?php echo $row['peserta_JUDUL']; ?></td>
                    <td>
                        <?php if ($row['peserta_DOKUMEN'] == "") {
                            echo "<img src='images/noimage.jpeg' width='88'/>";
                        } else { ?>
                            <img src="images/<?php echo $row['peserta_DOKUMEN']; ?>" width="88"/>
                        <?php } ?>
                    </td>
                    <td>
                        <a href="editpesertaskripsi.php?ubah=<?php echo $row['mhs_NPM']; ?>" class="btn btn-success btn-sm">Edit</a>
                    </td>
                    <td>
                        <a href="inputpesertaskripsi.php?hapus=<?php echo $row['mhs_NPM']; ?>" 
                           class="btn btn-danger btn-sm" 
                           onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                    </td>
                </tr>
                <?php } ?>
            </table>

        </div>
        </div>

    </div>
    </main>

    <?php include "bagiankode/footer.php"; ?>

    </div>
</div>

<!-- JS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/js/select2.min.js"></script>

<script>
$(document).ready(function(){
    $('#npmMHS').select2();
});
</script>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</html>