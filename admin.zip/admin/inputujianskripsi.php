<!DOCTYPE html>
<html>
    <?php
    include "bagiankode/head.php";
    ?>
    <?php
    ob_start();
    session_start();
    if(!isset($_SESSION['useremail']))
        header("location:login.php");
    ?>
    <body class="sb-nav-fixed">
        <?php
        include "bagiankode/menunav.php";
        ?>
        <div id="layoutSidenav">
            <?php
            include "bagiankode/menu.php";
            ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Ujian Skripsi</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Input Ujian Skripsi</li>
                        </ol>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Input Ujian Skripsi</title>

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/css/select2.min.css">
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.13.1/font/bootstrap-icons.min.css">
</head>
<body>

<?php include("includes/config.php");
if (isset($_POST['Simpan'])) {

    $mhs_NPM        = $_POST['npmMHS'];
    $dosen_NIDN     = $_POST['nidnDosen'];
    $tanggal_UJIAN  = $_POST['tanggal_UJIAN'];
    $waktu_UJIAN    = $_POST['waktu_UJIAN'];

    $foto_UJIAN     = $_FILES['dokumen']['name'];
    $dokumen_tmp    = $_FILES['dokumen']['tmp_name'];
    if ($foto_UJIAN != "") {
        move_uploaded_file($dokumen_tmp, 'images/' . $foto_UJIAN);
    }

    mysqli_query($conn, "INSERT INTO ujianskripsi
        (mhs_NPM, dosen_NIDN, TGL_ujian, WKT_ujian, foto_UJIAN)
        VALUES
        ('$mhs_NPM', '$dosen_NIDN', '$tanggal_UJIAN', '$waktu_UJIAN', '$foto_UJIAN')");

    header("location:inputujianskripsi.php");
    exit;
}
$datamhs   = mysqli_query($conn, "SELECT * FROM mahasiswa");
$datadosen = mysqli_query($conn, "SELECT * FROM dosen");
$query_base = "SELECT * FROM ujianskripsi 
               JOIN mahasiswa ON ujianskripsi.mhs_NPM = mahasiswa.mhs_NPM
               JOIN dosen     ON ujianskripsi.dosen_NIDN = dosen.dosen_NIDN";

if (isset($_POST["kirim"])) {
    $search = $_POST["search"];
    $query_display = mysqli_query($conn,
        $query_base . " WHERE ujianskripsi.mhs_NPM LIKE '%" . $search . "%'");
} else {
    $query_display = mysqli_query($conn, $query_base);
}
?>

<div class="container">
    <div class="row">
        <div class="col-1"></div>
        <div class="col-10">

            <h3 class="mt-5">Formulir Ujian Skripsi</h3>

            <form method="POST" enctype="multipart/form-data">

                <div class="row mb-3 mt-4">
                    <label for="npmMHS" class="col-sm-3 col-form-label">NPM Mahasiswa</label>
                    <div class="col-sm-9">
                        <select class="form-control" id="npmMHS" name="npmMHS">
                            <option>Cari NPM Mahasiswa</option>
                            <?php while ($row_mhs = mysqli_fetch_array($datamhs)) { ?>
                                <option value="<?php echo $row_mhs["mhs_NPM"] ?>">
                                    <?php echo $row_mhs["mhs_NPM"] ?> - <?php echo $row_mhs["mhs_Nama"] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="nidnDosen" class="col-sm-3 col-form-label">NIDN Dosen Penguji</label>
                    <div class="col-sm-9">
                        <select class="form-control" id="nidnDosen" name="nidnDosen">
                            <option>Cari NIDN Dosen</option>
                            <?php while ($row_dsn = mysqli_fetch_array($datadosen)) { ?>
                                <option value="<?php echo $row_dsn["dosen_NIDN"] ?>">
                                    <?php echo $row_dsn["dosen_NIDN"] ?> - <?php echo $row_dsn["dosen_Nama"] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="tanggal_UJIAN" class="col-sm-3 col-form-label">Tanggal Ujian</label>
                    <div class="col-sm-9">
                        <input type="date" class="form-control" id="tanggal_UJIAN" name="tanggal_UJIAN">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="waktu_UJIAN" class="col-sm-3 col-form-label">Waktu Ujian</label>
                    <div class="col-sm-9">
                        <input type="time" class="form-control" id="waktu_UJIAN" name="waktu_UJIAN">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="dokumen" class="col-sm-3 col-form-label">Foto Ujian (Gambar)</label>
                    <div class="col-sm-9">
                        <input type="file" class="form-control" id="dokumen" name="dokumen">
                    </div>
                </div>

                <div class="form-group row mt-4">
                    <div class="col-sm-3"></div>
                    <div class="col-sm-9">
                        <input type="submit" class="btn btn-success" value="Simpan" name="Simpan">
                        <input type="reset" class="btn btn-danger" value="Batal" name="Batal">
                    </div>
                </div>
            </form>

            <hr class="my-5">
            <div class="jumbotron mt-5 mb-3">
                <h3 class="display-5">Data Ujian Skripsi</h3>
            </div>

            <!-- FORM PENCARIAN -->
            <form method="POST">
                <div class="form-group row mt-5 mb-3">
                    <label for="search" class="col-sm-3">Cari NPM Mahasiswa</label>
                    <div class="col-sm-7">
                        <input type="text" name="search" class="form-control" id="search"
                               placeholder="Cari NPM Mahasiswa"
                               value="<?php if(isset($_POST["search"])) {echo $_POST["search"];}?>">
                    </div>
                    <input type="submit" name="kirim" value="Cari" class="col-sm-2 btn btn-primary">
                </div>
            </form>

            <!-- TABEL DATA -->
            <table class="table table-striped table-success table-hover">
                <tr class="info">
                    <th>NPM</th>
                    <th>Nama Mahasiswa</th>
                    <th>NIDN</th>
                    <th>Nama Dosen</th>
                    <th>Tanggal Ujian</th>
                    <th>Waktu Ujian</th>
                    <th>Foto Ujian</th>
                    <th colspan="2" style="text-align: center;">Aksi</th>
                </tr>

                <?php while ($row = mysqli_fetch_array($query_display)) { ?>
                    <tr class="danger">
                        <td><?php echo $row['mhs_NPM']; ?></td>
                        <td><?php echo $row['mhs_Nama']; ?></td>
                        <td><?php echo $row['dosen_NIDN']; ?></td>
                        <td><?php echo $row['dosen_Nama']; ?></td>
                        <td><?php echo $row['TGL_ujian']; ?></td>
                        <td><?php echo $row['WKT_ujian']; ?></td>

                        <td>
                            <?php if ($row['foto_ujian'] == "") {
                                echo "<img src='images/noimages.jpeg' width='88'/>";
                            } else { ?>
                                <img src="images/<?php echo $row['foto_ujian'] ?>" width="88" class="img-responsive" />
                            <?php } ?>
                        </td>
                            <td>
                            <a href="editujianskripsi.php?editujianskripsi=<?php echo $row['mhs_NPM']; ?>"
                            class="btn btn-success" title="EDIT">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                        </td>
                        <td>
                            <a href="hapusujianskripsi.php?hapusujianskripsi=<?php echo $row['mhs_NPM']; ?>"
                            class="btn btn-danger" title="HAPUS"
                            onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </table>

        </div>
        <div class="col-1"></div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('#npmMHS').select2();
    });
</script>

</body>
                    </div>
                </main>
                <?php
                include "bagiankode/footer.php";
                ?>
            </div>
        </div>
        <?php
        include "bagiankode/jsscript.php";
        ?>
    </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</html>