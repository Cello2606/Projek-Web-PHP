<?php
include("includes/config.php");

$npm = $_GET['npm'];

mysqli_query($conn, "DELETE FROM mahasiswa WHERE mhs_NPM = '$npm'");

echo "<script>alert('Data mahasiswa berhasil dihapus');location='inputmhs.php';</script>";
?>
