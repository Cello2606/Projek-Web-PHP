<?php
ob_start();
session_start();
if (!isset($_SESSION['useremail'])) {
    header("location:login.php");
    exit;
}

include("includes/config.php");

// Ambil NPM dari URL
if (!isset($_GET['npm'])) {
    echo "<script>alert('Parameter NPM tidak ditemukan');location='inputmhs.php';</script>";
    exit;
}

$npm = $_GET["npm"];

// Ambil Data Mahasiswa yg mau diedit
$q = mysqli_query($conn, "SELECT * FROM mahasiswa WHERE mhs_NPM = '$npm'");
$data = mysqli_fetch_assoc($q);

if (!$data) {
    echo "<script>alert('Data tidak ditemukan');location='inputmhs.php';</script>";
    exit;
}

// ================= UPDATE DATA =================
if (isset($_POST['update'])) {

    $nama   = $_POST['namaMHS'];
    $alamat = $_POST['alamatMHS'];
    $lahir  = $_POST['lahirMHS'];
    $ket    = $_POST['ketMHS'];

    mysqli_query($conn, "
        UPDATE mahasiswa SET 
            mhs_Nama   = '$nama',
            mhs_Alamat = '$alamat',
            mhs_DOB    = '$lahir',
            mhs_Ket    = '$ket'
        WHERE mhs_NPM = '$npm'
    ");

    echo "<script>alert('Data berhasil diupdate');location='inputmhs.php';</script>";
    exit;
}

// QUERY DATA MAHASISWA UNTUK TABEL DI BAWAH
$query = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY mhs_NPM ASC");
?>

<!DOCTYPE html>
<html>
    <?php include "bagiankode/head.php"; ?>
<body class="sb-nav-fixed">

<?php include "bagiankode/menunav.php"; ?>

<div id="layoutSidenav">

    <?php include "bagiankode/menu.php"; ?>

    <div id="layoutSidenav_content">
        <main>

            <div class="container-fluid px-4">

                <h1 class="mt-4">Edit Mahasiswa</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="inputmhs.php">Mahasiswa</a></li>
                    <li class="breadcrumb-item active">Edit Mahasiswa</li>
                </ol>

                <!-- FORM EDIT -->
                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-10">

                        <div class="card mb-4">
                            <div class="card-header bg-warning text-white">
                                Form Edit Mahasiswa
                            </div>

                            <div class="card-body">
                                <form method="POST">

                                    <div class="mb-3">
                                        <label>NPM</label>
                                        <input type="text" class="form-control" 
                                               value="<?= $data['mhs_NPM']; ?>" readonly>
                                    </div>

                                    <div class="mb-3">
                                        <label>Nama Mahasiswa</label>
                                        <input type="text" class="form-control" name="namaMHS" 
                                               value="<?= $data['mhs_Nama']; ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label>Alamat Mahasiswa</label>
                                        <input type="text" class="form-control" name="alamatMHS" 
                                               value="<?= $data['mhs_Alamat']; ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label>Tanggal Lahir</label>
                                        <input type="date" class="form-control" name="lahirMHS" 
                                               value="<?= $data['mhs_DOB']; ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label>Keterangan</label>
                                        <input type="text" class="form-control" name="ketMHS" 
                                               value="<?= $data['mhs_Ket']; ?>">
                                    </div>

                                    <button type="submit" name="update" class="btn btn-success">
                                        Update
                                    </button>
                                    <a href="inputmhs.php" class="btn btn-secondary">
                                        Kembali
                                    </a>

                                </form>
                            </div>
                        </div>

                    </div>
                    <div class="col-1"></div>
                </div>

                <!-- TABEL MAHASISWA -->
                <div class="row mt-3">
                    <div class="col-1"></div>
                    <div class="col-10">

                        <div class="jumbotron mb-3">
                            <h3 class="display-6">Daftar Mahasiswa</h3>
                        </div>

                        <table class="table table-striped table-success table-hover">
                            <thead>
                                <tr>
                                    <th>NPM</th>
                                    <th>Nama</th>
                                    <th>Alamat</th>
                                    <th>Tgl Lahir</th>
                                    <th>Keterangan</th>
                                    <th style="text-align:center;">Aksi</th>
                                </tr>
                            </thead>

                            <tbody>
                            <?php while ($row = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?= $row['mhs_NPM']; ?></td>
                                    <td><?= $row['mhs_Nama']; ?></td>
                                    <td><?= $row['mhs_Alamat']; ?></td>
                                    <td><?= $row['mhs_DOB']; ?></td>
                                    <td><?= $row['mhs_Ket']; ?></td>

                                    <td style="text-align:center;">
                                        <div class="btn-group" role="group" aria-label="Aksi">
                                            <a href="editmhs.php?npm=<?= $row['mhs_NPM']; ?>"
                                               class="btn btn-warning btn-sm">Edit</a>

                                            <a href="hapusmhs.php?npm=<?= $row['mhs_NPM']; ?>"
                                               class="btn btn-danger btn-sm"
                                               onclick="return confirm('Yakin ingin menghapus?');">
                                                Hapus
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>

                    </div>
                    <div class="col-1"></div>
                </div>

            </div>

        </main>

        <?php include "bagiankode/footer.php"; ?>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>