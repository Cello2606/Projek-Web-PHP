<?php
ob_start();
session_start();
if (!isset($_SESSION['useremail'])) {
    header("location:login.php");
    exit;
}

include "includes/config.php";

// ====================== AMBIL NPM DARI LINK ======================
if (!isset($_GET['editujianskripsi'])) {
    echo "<script>alert('Parameter tidak valid');location='inputujianskripsi.php';</script>";
    exit;
}

$npm = $_GET['editujianskripsi'];

// ====================== AMBIL DATA UJIAN (UNTUK PREFILL FORM) ======================
$q_ujian = mysqli_query($conn, "
    SELECT ujianskripsi.*, mahasiswa.mhs_Nama, dosen.dosen_Nama
    FROM ujianskripsi
    JOIN mahasiswa ON ujianskripsi.mhs_NPM = mahasiswa.mhs_NPM
    JOIN dosen     ON ujianskripsi.dosen_NIDN = dosen.dosen_NIDN
    WHERE ujianskripsi.mhs_NPM = '$npm'
");

$data = mysqli_fetch_assoc($q_ujian);

if (!$data) {
    echo "<script>alert('Data ujian tidak ditemukan');location='inputujianskripsi.php';</script>";
    exit;
}

// ====================== DROPDOWN DOSEN ======================
$datadosen = mysqli_query($conn, "SELECT * FROM dosen ORDER BY dosen_Nama ASC");

// ====================== PROSES UPDATE ======================
if (isset($_POST['update'])) {

    $nidn = $_POST['nidn'];
    $tgl  = $_POST['tgl'];
    $wkt  = $_POST['wkt'];

    $foto_lama = $data['foto_ujian'];

    // Jika ada foto baru
    if (!empty($_FILES['foto']['name'])) {

        $foto = $_FILES['foto']['name'];
        $tmp  = $_FILES['foto']['tmp_name'];

        move_uploaded_file($tmp, "images/" . $foto);

        $nama_foto = $foto;
    } else {
        // Kalau tidak upload baru, gunakan foto lama
        $nama_foto = $foto_lama;
    }

    mysqli_query($conn, "
        UPDATE ujianskripsi
        SET dosen_NIDN = '$nidn',
            TGL_ujian  = '$tgl',
            WKT_ujian  = '$wkt',
            foto_ujian = '$nama_foto'
        WHERE mhs_NPM = '$npm'
    ");

    echo "<script>alert('Data ujian berhasil diubah');location='inputujianskripsi.php';</script>";
    exit;
}

// ====================== DATA UNTUK TABEL DI BAWAH ======================

$query_base = "SELECT * FROM ujianskripsi 
               JOIN mahasiswa ON ujianskripsi.mhs_NPM = mahasiswa.mhs_NPM
               JOIN dosen     ON ujianskripsi.dosen_NIDN = dosen.dosen_NIDN";

if (isset($_POST["kirim"])) {
    $search = $_POST["search"];
    $query_display = mysqli_query($conn,
        $query_base . " WHERE ujianskripsi.mhs_NPM LIKE '%" . $search . "%'");
} else {
    $query_display = mysqli_query($conn, $query_base);
}
?>

<!DOCTYPE html>
<html>
    <?php
    include "bagiankode/head.php";
    ?>
    <body class="sb-nav-fixed">
        <?php
        include "bagiankode/menunav.php";
        ?>
        <div id="layoutSidenav">
            <?php
            include "bagiankode/menu.php";
            ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Ujian Skripsi</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="inputujianskripsi.php">Ujian Skripsi</a></li>
                            <li class="breadcrumb-item active">Edit Ujian Skripsi</li>
                        </ol>

                        <div class="container">
                            <div class="row">
                                <div class="col-1"></div>
                                <div class="col-10">

                                    <h3 class="mt-4 mb-3">Form Edit Ujian Skripsi</h3>

                                    <!-- FORM EDIT -->
                                    <form method="POST" enctype="multipart/form-data" class="mb-5">

                                        <div class="row mb-3">
                                            <label class="col-sm-3 col-form-label">NPM Mahasiswa</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control"
                                                       value="<?= $data['mhs_NPM']; ?> - <?= $data['mhs_Nama']; ?>"
                                                       readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label class="col-sm-3 col-form-label">NIDN Dosen Penguji</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" name="nidn" required>
                                                    <option value="">Pilih NIDN Dosen</option>
                                                    <?php while ($row_dsn = mysqli_fetch_assoc($datadosen)) { ?>
                                                        <option value="<?= $row_dsn["dosen_NIDN"] ?>"
                                                            <?= ($row_dsn["dosen_NIDN"] == $data['dosen_NIDN']) ? 'selected' : ''; ?>>
                                                            <?= $row_dsn["dosen_NIDN"] ?> - <?= $row_dsn["dosen_Nama"] ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label class="col-sm-3 col-form-label">Tanggal Ujian</label>
                                            <div class="col-sm-9">
                                                <input type="date" class="form-control" name="tgl"
                                                       value="<?= $data['TGL_ujian']; ?>">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label class="col-sm-3 col-form-label">Waktu Ujian</label>
                                            <div class="col-sm-9">
                                                <input type="time" class="form-control" name="wkt"
                                                       value="<?= $data['WKT_ujian']; ?>">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label class="col-sm-3 col-form-label">Foto Ujian Saat Ini</label>
                                            <div class="col-sm-9">
                                                <?php if (empty($data['foto_ujian'])) { ?>
                                                    <span class="text-danger">Belum ada foto</span>
                                                <?php } else { ?>
                                                    <img src="images/<?= $data['foto_ujian']; ?>" width="120"
                                                         class="img-thumbnail mb-2">
                                                <?php } ?>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label class="col-sm-3 col-form-label">Ganti Foto Ujian</label>
                                            <div class="col-sm-9">
                                                <input type="file" class="form-control" name="foto" accept="image/*">
                                                <small class="text-muted">Biarkan kosong jika tidak ingin mengubah foto.</small>
                                            </div>
                                        </div>

                                        <div class="form-group row mt-4">
                                            <div class="col-sm-3"></div>
                                            <div class="col-sm-9">
                                                <button type="submit" class="btn btn-success" name="update">Simpan Perubahan</button>
                                                <a href="inputujianskripsi.php" class="btn btn-secondary">Kembali</a>
                                            </div>
                                        </div>

                                    </form>

                                    <hr class="my-4">

                                    <div class="jumbotron mt-4 mb-3">
                                        <h3 class="display-5">Data Ujian Skripsi</h3>
                                    </div>

                                    <!-- FORM PENCARIAN -->
                                    <form method="POST">
                                        <div class="form-group row mt-3 mb-3">
                                            <label for="search" class="col-sm-3">Cari NPM Mahasiswa</label>
                                            <div class="col-sm-7">
                                                <input type="text" name="search" class="form-control" id="search"
                                                       placeholder="Cari NPM Mahasiswa"
                                                       value="<?php if(isset($_POST["search"])) {echo $_POST["search"];}?>">
                                            </div>
                                            <input type="submit" name="kirim" value="Cari" class="col-sm-2 btn btn-primary">
                                        </div>
                                    </form>

                                    <!-- TABEL DATA -->
                                    <table class="table table-striped table-success table-hover">
                                        <tr class="info">
                                            <th>NPM</th>
                                            <th>Nama Mahasiswa</th>
                                            <th>NIDN</th>
                                            <th>Nama Dosen</th>
                                            <th>Tanggal Ujian</th>
                                            <th>Waktu Ujian</th>
                                            <th>Foto Ujian</th>
                                            <th colspan="2" style="text-align: center;">Aksi</th>
                                        </tr>

                                        <?php while ($row = mysqli_fetch_array($query_display)) { ?>
                                            <tr class="danger">
                                                <td><?php echo $row['mhs_NPM']; ?></td>
                                                <td><?php echo $row['mhs_Nama']; ?></td>
                                                <td><?php echo $row['dosen_NIDN']; ?></td>
                                                <td><?php echo $row['dosen_Nama']; ?></td>
                                                <td><?php echo $row['TGL_ujian']; ?></td>
                                                <td><?php echo $row['WKT_ujian']; ?></td>

                                                <td>
                                                    <?php if ($row['foto_ujian'] == "") {
                                                        echo "<img src='images/noimages.jpeg' width='88'/>";
                                                    } else { ?>
                                                        <img src="images/<?php echo $row['foto_ujian'] ?>" width="88" class="img-responsive" />
                                                    <?php } ?>
                                                </td>

                                                <td>
                                                    <a href="editujianskripsi.php?editujianskripsi=<?php echo $row["mhs_NPM"]?>"
                                                       class="btn btn-success" title="EDIT">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                                             class="bi bi-pencil-square" viewBox="0 0 16 16">
                                                            <path
                                                                d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.691l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.121l6.813-6.814z" />
                                                            <path fill-rule="evenodd"
                                                                d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                                                        </svg>
                                                    </a>
                                                </td>

                                                <td>
                                                <a href="hapusujianskripsi.php?hapusujianskripsi=<?php echo $row["mhs_NPM"]?>"
                                            class="btn btn-danger" title="HAPUS"
                                            onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                            </td>
                                            </tr>
                                        <?php } ?>
                                    </table>

                                </div>
                                <div class="col-1"></div>
                            </div>
                        </div>

                    </div>
                </main>
                <?php
                include "bagiankode/footer.php";
                ?>
            </div>
        </div>
        <?php
        include "bagiankode/jsscript.php";
        ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>