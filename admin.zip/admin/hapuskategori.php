<?php

include "includes/config.php"; 


if(isset($_GET['hapuskategori']))
{
  
    $NPM = $_GET["hapuskategori"]; 
    

    mysqli_query($conn, "DELETE FROM kategoriskripsi WHERE mhs_NPM = '$NPM'");
    
    
    echo "<script>alert('DATA BERHASIL DIHAPUS');";
    echo "document.location='inputkategori.php'</script>";
}
?>