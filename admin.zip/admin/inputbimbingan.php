<!DOCTYPE html>
<html>
    <?php
include "bagiankode/head.php";
?>
<!-- biar ga bisa langusng ke website input , dan ini proteksi biar ke login dlu -->
<?php
ob_start();
session_start();
if(!isset($_SESSION['useremail']))
header("location:login.php");
?>
<body class="sb-nav-fixed">
<?php
include "bagiankode/menunav.php";
?>
    <div id="layoutSidenav">
        <?php
include "bagiankode/menu.php";
?>

<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">
    <h1 class="mt-4">Input Bimbingan</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Bimbingan</li>
    </ol>
<?php
include("includes/config.php");
if (isset($_POST['simpan'])) {
    $npm  = $_POST['npmMHS'];
    $nidn = $_POST['nidnDOSEN'];
    $tgl  = $_POST['tgl'];
    $isi  = $_POST['isi'];
    $file = $_FILES['dokumen']['name'];
    $tmp  = $_FILES['dokumen']['tmp_name'];
    if ($file != "") {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if ($ext != "pdf") {
            echo "<script>alert('File harus PDF');</script>";
            exit;
        }
        if (!is_dir("uploads")) mkdir("uploads");
        move_uploaded_file($tmp, "uploads/" . $file);
    }

    mysqli_query($conn, "
        INSERT INTO bimbinganskripsi
        (mhs_NPM, dosen_NIDN, TGL_bimbingan, ISI_bimbingan, dokumen)
        VALUES ('$npm', '$nidn', '$tgl', '$isi', '$file')
    ");

    echo "<script>location='inputbimbingan.php';</script>";
}
$where = "";
$filter_npm = "";
$filter_dosen = "";

if (isset($_POST['cari'])) {

    if (!empty($_POST['search_npm'])) {
        $filter_npm = $_POST['search_npm'];
        $where .= " AND bimbinganskripsi.mhs_NPM LIKE '%$filter_npm%' ";
    }

    if (!empty($_POST['search_dosen'])) {
        $filter_dosen = $_POST['search_dosen'];
        $where .= " AND bimbinganskripsi.dosen_NIDN = '$filter_dosen' ";
    }
}
$data = mysqli_query($conn, "
    SELECT * FROM bimbinganskripsi
    JOIN mahasiswa ON mahasiswa.mhs_NPM = bimbinganskripsi.mhs_NPM
    JOIN dosen ON dosen.dosen_NIDN = bimbinganskripsi.dosen_NIDN
    WHERE 1=1 $where
    ORDER BY bimbinganskripsi.TGL_bimbingan DESC
");

$datamhs   = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY mhs_Nama ASC");
$datadosen = mysqli_query($conn, "SELECT * FROM dosen ORDER BY dosen_Nama ASC");
?>
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Tambah Bimbingan</div>
        <div class="card-body">

            <form method="POST" enctype="multipart/form-data">

                <div class="mb-3">
                    <label>NPM Mahasiswa</label>
                    <select class="form-control" name="npmMHS" required>
                        <option value="">-- Pilih Mahasiswa --</option>
                        <?php while($m = mysqli_fetch_assoc($datamhs)) { ?>
                            <option value="<?= $m['mhs_NPM']; ?>">
                                <?= $m['mhs_NPM']; ?> - <?= $m['mhs_Nama']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Dosen Pembimbing</label>
                    <select class="form-control" name="nidnDOSEN" required>
                        <option value="">-- Pilih Dosen --</option>
                        <?php while($d = mysqli_fetch_assoc($datadosen)) { ?>
                            <option value="<?= $d['dosen_NIDN']; ?>">
                                <?= $d['dosen_NIDN']; ?> - <?= $d['dosen_Nama']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Tanggal Bimbingan</label>
                    <input type="date" class="form-control" name="tgl" required>
                </div>

                <div class="mb-3">
                    <label>Isi Bimbingan</label>
                    <textarea class="form-control" name="isi" rows="3" required></textarea>
                </div>

                <div class="mb-3">
                    <label>Upload Dokumen (PDF)</label>
                    <input type="file" class="form-control" name="dokumen" accept="application/pdf" required>
                </div>

                <button class="btn btn-success" name="simpan">Simpan</button>

            </form>

        </div>
    </div>
    <div class="card mb-4">
        <div class="card-header bg-secondary text-white">Filter Pencarian</div>
        <div class="card-body">

            <form method="POST" class="row">

                <div class="col-md-4 mb-3">
                    <label>Cari NPM</label>
                    <input type="text" name="search_npm" class="form-control"
                        value="<?= $filter_npm; ?>">
                </div>

                <div class="col-md-4 mb-3">
                    <label>Filter Dosen</label>
                    <select name="search_dosen" class="form-control">
                        <option value="">Semua Dosen</option>
                        <?php
                        $ds = mysqli_query($conn, "SELECT * FROM dosen");
                        while ($s = mysqli_fetch_assoc($ds)) { ?>
                            <option value="<?= $s['dosen_NIDN']; ?>"
                                <?= $filter_dosen == $s['dosen_NIDN'] ? "selected" : ""; ?>>
                                <?= $s['dosen_Nama']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="col-md-4 mb-3 d-flex align-items-end">
                    <button class="btn btn-primary w-100" name="cari">Cari</button>
                </div>

            </form>

        </div>
    </div>
    <div class="card mb-4">
        <div class="card-header bg-dark text-white">Data Bimbingan Skripsi</div>
        <div class="card-body">

        <table class="table table-bordered table-striped">
            <thead class="table-success">
                <tr>
                    <th>NPM</th>
                    <th>Nama</th>
                    <th>Dosen</th>
                    <th>Tanggal</th>
                    <th>Isi</th>
                    <th>Dokumen</th>
                    <th width="150px">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($b = mysqli_fetch_assoc($data)) { ?>
                <tr>
                    <td><?= $b['mhs_NPM']; ?></td>
                    <td><?= $b['mhs_Nama']; ?></td>
                    <td><?= $b['dosen_Nama']; ?></td>
                    <td><?= $b['TGL_bimbingan']; ?></td>
                    <td><?= $b['ISI_bimbingan']; ?></td>

                    <td>
                        <?php if ($b['dokumen'] == "") { ?>
                            <span class="text-danger">Tidak ada file</span>
                        <?php } else { ?>
                            <a href="uploads/<?= $b['dokumen']; ?>" class="btn btn-sm btn-primary" target="_blank">PDF</a>
                        <?php } ?>
                    </td>

                    <td>
                        <a href="editbimbingan.php?npm=<?= $b['mhs_NPM']; ?>&nidn=<?= $b['dosen_NIDN']; ?>&tgl=<?= $b['TGL_bimbingan']; ?>"
                           class="btn btn-warning btn-sm">Edit</a>

                        <a onclick="return confirm('Hapus data?')" 
                           href="hapusbimbingan.php?npm=<?= $b['mhs_NPM']; ?>&nidn=<?= $b['dosen_NIDN']; ?>&tgl=<?= $b['TGL_bimbingan']; ?>"
                           class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
</main>

<?php include "bagiankode/footer.php"; ?>

</div>
</div>

</body>
</html>
