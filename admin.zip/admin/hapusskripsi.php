<?php

include "includes/config.php"; 


if(isset($_GET['hapusskirpsi']))
{
  
    $NPM = $_GET["hapusskripsi"]; 
    

    mysqli_query($conn, "DELETE FROM pesertaskripsi WHERE mhs_NPM = '$NPM'");
    
    
    echo "<script>alert('DATA BERHASIL DIHAPUS');";
    echo "document.location='inputpesertaskripsi.php'</script>";
}
?>