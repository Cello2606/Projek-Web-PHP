[10/28/2025 12:42 PM] Gilbert: <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Input Peserta Skripsi</title>

        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/css/select2.min.css">
    </head>
    <body>
    <?php
    include('../includes/config.php');

    if(isset($_POST['Simpan'])) {
        $mhs_NPM = $_POST['mhs_NPM'];
        $peserta_SEMT = $_POST['peserta_SEMT'];
        $Peserta_THAKD = $_POST['Peserta_THAKD'];
        $Peserta_TGLDAFTAR = $_POST['Peserta_TGLDAFTAR'];
        $Peserta_JUDUL = $_POST['Peserta_JUDUL'];

        // Check for duplicate mhs_NPM
        $check_duplicate = mysqli_query($con, "SELECT * FROM persertaskripsi WHERE mhs_NPM = '$mhs_NPM'");
        if (mysqli_num_rows($check_duplicate) > 0) {
            echo "<script>alert('Mahasiswa dengan NPM ini sudah terdaftar sebagai peserta skripsi!');</script>";
        } else {
            $Peserta_DOKUMEN = $_FILES['Peserta_DOKUMEN']['name'];
            $dokumen_tmp = $_FILES['Peserta_DOKUMEN']['tmp_name'];
            move_uploaded_file($dokumen_tmp, 'images/' . $Peserta_DOKUMEN);

            mysqli_query($con, "INSERT INTO persertaskripsi (mhs_NPM, peserta_SEMT, peserta_THAKD, peserta_TGLDAFTAR, peserta_judul, peserta_dokument) VALUES ('$mhs_NPM', '$peserta_SEMT', '$Peserta_THAKD', '$Peserta_TGLDAFTAR', '$Peserta_JUDUL', '$Peserta_DOKUMEN')");
            header("location:inputpesertaskripsi.php");
        }
    }

    $query = mysqli_query($con, "SELECT * FROM persertaskripsi, mahasiswa WHERE mahasiswa.mhs_NPM = persertaskripsi.mhs_NPM");
    $datamhs = mysqli_query($con, "SELECT * FROM mahasiswa");
    ?>
        <div class="row">
            <div class="col-1"></div>
            <div class="col-10">
                <form method="POST" enctype="multipart/form-data">
                    <div class="row mb-3 mt-5">
                        <label for="mhs_NPM" class="col-sm-2 col-form-label">NPM Mahasiswa</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="mhs_NPM" name="mhs_NPM">
                                <option>Cari NPM Mahasiswa</option>
                                <?php while ($row = mysqli_fetch_array($datamhs)) { ?>
                                    <option value="<?php echo $row["mhs_NPM"] ?>">
                                        <?php echo $row["mhs_NPM"] ?> - <?php echo $row["mhs_Nama"] ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="peserta_SEMT" class="col-sm-2 col-form-label">Semester</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="peserta_SEMT" name="peserta_SEMT">
                                <option value="">Pilih Semester</option>
                                <option value="Ganjil">Ganjil</option>
                                <option value="Genap">Genap</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="Peserta_THAKD" class="col-sm-2 col-form-label">Tahun Akademik</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="Peserta_THAKD" name="Peserta_THAKD" placeholder="2025-2026">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="Peserta_TGLDAFTAR" class="col-sm-2 col-form-label">Tanggal Daftar</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" id="Peserta_TGLDAFTAR" name="Peserta_TGLDAFTAR">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="Peserta_JUDUL" class="col-sm-2 col-form-label">Judul</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="Peserta_JUDUL" name="Peserta_JUDUL">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="Peserta_DOKUMEN" class="col-sm-2 col-form-label">Unggah Dokumen</label>
                        <div class="col-sm-10">
                            <input type="file" class="form-control" id="Peserta_DOKUMEN" name="Peserta_DOKUMEN" accept="image/*">
                            <p class="help-block">Unggah file gambar</p>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-2"></div>
                        <div class="col-10">
                            <input type="submit" class="btn btn-success" value="Simpan" name="Simpan">
                            <input type="reset" class="btn btn-danger" value="Batal" name="Batal">
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <div class="col-1"></div>
            <div class="col-10">
                <div class="jumbotron mt-5 mb-3">
                    <h3 class="display-5">Daftar Peserta Skripsi</h3>
                </div>

                <table class="table table-striped table-success table-hover">
                    <tr class="info">
                        <th>NPM</th>
                        <th>Nama Mahasiswa</th>
                        <th>Semester</th>
                        <th>Tahun Akademik</th>
                        <th>Tanggal Daftar</th>
                        <th>Judul</th>
                        <th>Dokumen</th>
                    </tr>

                    <?php while ($row = mysqli_fetch_array($query)) { ?>
                        <tr class="danger">
                            <td><?php echo $row['mhs_NPM']; ?></td>
                            <td><?php echo $row['mhs_Nama']; ?></td>
                            <td><?php echo $row['peserta_SEMT']; ?></td>
                            <td><?php echo $row['peserta_THAKD']; ?></td>
                            <td><?php echo $row['peserta_TGLDAFTAR']; ?></td>
                            <td><?php echo $row['peserta_judul']; ?></td>
                            <td>
                                <?php if ($row['peserta_dokument'] == "") {
                                    echo "<img src='images/noimage.png' width='88' class='img-responsive' />";
                                } else { ?>
                                    <img src="images/<?php echo $row['peserta_dokument']; ?>" width="88" class="img-responsive" />
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </table>
            </div>
        </div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/js/select2.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#mhs_NPM').select2();
            });
        </script>
    </body>
</html>
