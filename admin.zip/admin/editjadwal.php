<?php
ob_start();
session_start();
if(!isset($_SESSION['useremail'])) {
    header("location:login.php");
    exit;
}

include("includes/config.php");

// ====================== AMBIL PARAMETER KUNCI DARI URL ======================
if (
    !isset($_GET['npm']) ||
    !isset($_GET['nidn']) ||
    !isset($_GET['tgl']) ||
    !isset($_GET['waktu'])
) {
    echo "<script>alert('Parameter tidak lengkap');location='inputjadwal.php';</script>";
    exit;
}

$npm_lama    = $_GET['npm'];
$nidn_lama   = $_GET['nidn'];
$tgl_lama    = $_GET['tgl'];
$waktu_lama  = $_GET['waktu'];

// ====================== AMBIL DATA JADWAL YANG MAU DIEDIT ======================
$q_jadwal = mysqli_query($conn, "
    SELECT jadwalskripsi.*,
           mahasiswa.mhs_Nama,
           dosen.dosen_Nama
    FROM jadwalskripsi
    JOIN mahasiswa ON mahasiswa.mhs_NPM = jadwalskripsi.mhs_NPM
    JOIN dosen     ON dosen.dosen_NIDN = jadwalskripsi.dosen_NIDN
    WHERE jadwalskripsi.mhs_NPM       = '$npm_lama'
      AND jadwalskripsi.dosen_NIDN    = '$nidn_lama'
      AND jadwalskripsi.tanggal_SKRIPSI = '$tgl_lama'
      AND jadwalskripsi.waktu_SKRIPSI   = '$waktu_lama'
");

$data_jadwal = mysqli_fetch_assoc($q_jadwal);

if (!$data_jadwal) {
    echo "<script>alert('Data jadwal tidak ditemukan');location='inputjadwal.php';</script>";
    exit;
}

// ====================== DATA UNTUK DROPDOWN ======================
$datamhs   = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY mhs_Nama ASC");
$datadosen = mysqli_query($conn, "SELECT * FROM dosen ORDER BY dosen_Nama ASC");

// ====================== PROSES UPDATE ======================
if (isset($_POST['update'])) {

    $mhs_NPM_baru         = $_POST['npmMHS'];
    $dosen_NIDN_baru      = $_POST['nidnDOSEN'];
    $waktu_SKRIPSI_baru   = $_POST['waktuSKRIPSI'];
    $tanggal_SKRIPSI_baru = $_POST['tglSKRIPSI'];
    $tempat_SKRIPSI_baru  = $_POST['tempatSKRIPSI'];
    $ruangan_SKRIPSI_baru = $_POST['ruanganSKRIPSI'];

    // Validasi minimal input
    if (empty($mhs_NPM_baru) || empty($dosen_NIDN_baru) || empty($tanggal_SKRIPSI_baru) || empty($waktu_SKRIPSI_baru)) {
        echo "<script>alert('NPM, Dosen, Tanggal dan Waktu wajib diisi');</script>";
    } else {

        mysqli_query($conn, "
            UPDATE jadwalskripsi SET
                mhs_NPM        = '$mhs_NPM_baru',
                dosen_NIDN     = '$dosen_NIDN_baru',
                waktu_SKRIPSI  = '$waktu_SKRIPSI_baru',
                tanggal_SKRIPSI= '$tanggal_SKRIPSI_baru',
                tempat_SKRIPSI = '$tempat_SKRIPSI_baru',
                ruangan_SKRIPSI= '$ruangan_SKRIPSI_baru'
            WHERE mhs_NPM        = '$npm_lama'
              AND dosen_NIDN     = '$nidn_lama'
              AND tanggal_SKRIPSI= '$tgl_lama'
              AND waktu_SKRIPSI  = '$waktu_lama'
        ");

        echo "<script>alert('Data jadwal skripsi berhasil diupdate');location='inputjadwal.php';</script>";
        exit;
    }
}

// ====================== DATA UNTUK TABEL DI BAWAH ======================
$query = mysqli_query($conn, "
    SELECT jadwalskripsi.*,
           mahasiswa.mhs_Nama,
           dosen.dosen_Nama
    FROM jadwalskripsi
    JOIN mahasiswa ON mahasiswa.mhs_NPM = jadwalskripsi.mhs_NPM
    JOIN dosen     ON dosen.dosen_NIDN = jadwalskripsi.dosen_NIDN
    ORDER BY jadwalskripsi.tanggal_SKRIPSI ASC, jadwalskripsi.waktu_SKRIPSI ASC
");
?>

<!DOCTYPE html>
<html>
    <?php
    include "bagiankode/head.php";
    ?>
<body class="sb-nav-fixed">
<?php
include "bagiankode/menunav.php";
?>
<div id="layoutSidenav">
    <?php
    include "bagiankode/menu.php";
    ?>

    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">

                <h1 class="mt-4">Edit Jadwal Skripsi</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="inputjadwal.php">Jadwal Skripsi</a></li>
                    <li class="breadcrumb-item active">Edit Jadwal Skripsi</li>
                </ol>

                <!-- FORM EDIT -->
                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-10">

                        <form method="POST" class="mb-4">

                            <!-- simpan kunci lama -->
                            <input type="hidden" name="npm_lama"   value="<?= $npm_lama; ?>">
                            <input type="hidden" name="nidn_lama"  value="<?= $nidn_lama; ?>">
                            <input type="hidden" name="tgl_lama"   value="<?= $tgl_lama; ?>">
                            <input type="hidden" name="waktu_lama" value="<?= $waktu_lama; ?>">

                            <div class="row mb-3 mt-4">
                                <label class="col-sm-2 col-form-label">NPM Mahasiswa</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="npmMHS" name="npmMHS" required>
                                        <option value="">-- Pilih Mahasiswa --</option>
                                        <?php while ($m = mysqli_fetch_assoc($datamhs)) { ?>
                                            <option value="<?= $m['mhs_NPM']; ?>"
                                                <?= ($m['mhs_NPM'] == $data_jadwal['mhs_NPM']) ? 'selected' : ''; ?>>
                                                <?= $m['mhs_NPM']; ?> - <?= $m['mhs_Nama']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">NIDN Dosen</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="nidnDOSEN" name="nidnDOSEN" required>
                                        <option value="">-- Pilih Dosen --</option>
                                        <?php while ($d = mysqli_fetch_assoc($datadosen)) { ?>
                                            <option value="<?= $d['dosen_NIDN']; ?>"
                                                <?= ($d['dosen_NIDN'] == $data_jadwal['dosen_NIDN']) ? 'selected' : ''; ?>>
                                                <?= $d['dosen_NIDN']; ?> - <?= $d['dosen_Nama']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Tanggal Skripsi</label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control"
                                           id="tglSKRIPSI" name="tglSKRIPSI"
                                           value="<?= $data_jadwal['tanggal_SKRIPSI']; ?>" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Waktu Skripsi</label>
                                <div class="col-sm-10">
                                    <input type="time" class="form-control"
                                           id="waktuSKRIPSI" name="waktuSKRIPSI"
                                           value="<?= $data_jadwal['waktu_SKRIPSI']; ?>" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Tempat</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control"
                                           id="tempatSKRIPSI" name="tempatSKRIPSI"
                                           value="<?= $data_jadwal['tempat_SKRIPSI']; ?>"
                                           placeholder="Contoh: Kampus A, Gedung B">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Ruangan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control"
                                           id="ruanganSKRIPSI" name="ruanganSKRIPSI"
                                           value="<?= $data_jadwal['ruangan_SKRIPSI']; ?>"
                                           placeholder="Contoh: Ruang 201 / Lab 3">
                                </div>
                            </div>

                            <div class="form-group row mb-4">
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-success" name="update">Simpan Perubahan</button>
                                    <a href="inputjadwal.php" class="btn btn-secondary">Kembali</a>
                                </div>
                            </div>

                        </form>

                    </div>
                    <div class="col-1"></div>
                </div>

                <!-- TABEL JADWAL SKRIPSI -->
                <div class="row mt-3">
                    <div class="col-1"></div>
                    <div class="col-10">

                        <div class="jumbotron mb-3">
                            <h3 class="display-6">Daftar Jadwal Skripsi</h3>
                        </div>

                        <table class="table table-striped table-success table-hover">
                            <thead>
                                <tr>
                                    <th>NPM</th>
                                    <th>Nama Mahasiswa</th>
                                    <th>NIDN</th>
                                    <th>Nama Dosen</th>
                                    <th>Tgl Skripsi</th>
                                    <th>Waktu</th>
                                    <th>Tempat</th>
                                    <th>Ruangan</th>
                                    <th style="text-align:center;">Aksi</th>
                                </tr>
                            </thead>

                            <tbody>
                            <?php while ($row = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?= $row['mhs_NPM']; ?></td>
                                    <td><?= $row['mhs_Nama']; ?></td>
                                    <td><?= $row['dosen_NIDN']; ?></td>
                                    <td><?= $row['dosen_Nama']; ?></td>
                                    <td><?= $row['tanggal_SKRIPSI']; ?></td>
                                    <td><?= $row['waktu_SKRIPSI']; ?></td>
                                    <td><?= $row['tempat_SKRIPSI']; ?></td>
                                    <td><?= $row['ruangan_SKRIPSI']; ?></td>

                                    <td style="text-align:center;">
                                        <a href="editjadwal.php?npm=<?= $row['mhs_NPM']; ?>&nidn=<?= $row['dosen_NIDN']; ?>&tgl=<?= $row['tanggal_SKRIPSI']; ?>&waktu=<?= $row['waktu_SKRIPSI']; ?>"
                                           class="btn btn-warning btn-sm">Edit</a>

                                        <a href="hapusjadwal.php?hapusjadwal=<?= $row['mhs_NPM']; ?>"
                    class="btn btn-danger btn-sm"
                    onclick="return confirm('Yakin ingin menghapus?');">
                    Hapus
                    </a>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>

                    </div>
                    <div class="col-1"></div>
                </div>

            </div>
        </main>

        <?php include "bagiankode/footer.php"; ?>

    </div>
</div>

<?php include "bagiankode/jsscript.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>