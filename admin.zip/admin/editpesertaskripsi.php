<?php
include "bagiankode/head.php";
ob_start();
session_start();
if(!isset($_SESSION['useremail'])) header("location:login.php");
include "includes/config.php";

// 1. AMBIL ID DARI URL
$NPM = $_GET["ubah"] ?? null;
if (!$NPM) { header("location: inputpesertaskripsi.php"); exit; }

// 2. AMBIL DATA PESERTA
$edit_peserta = mysqli_query($conn, "SELECT * FROM pesertaskripsi WHERE mhs_NPM = '$NPM'");
$row_edit = mysqli_fetch_array($edit_peserta);
if (!$row_edit) { header("location: inputpesertaskripsi.php"); exit; }

// 3. AMBIL DATA MAHASISWA
$edit_mhs = mysqli_query($conn, "SELECT * FROM mahasiswa WHERE mhs_NPM = '$NPM'");
$row_edit_mhs = mysqli_fetch_array($edit_mhs);
$datamhs = mysqli_query($conn, "SELECT * FROM mahasiswa");

// 4. QUERY TABEL PESERTA LAIN
$query_display = mysqli_query($conn, "SELECT * FROM pesertaskripsi 
    JOIN mahasiswa ON pesertaskripsi.mhs_NPM = mahasiswa.mhs_NPM");

// 5. PROSES UPDATE
if (isset($_POST['Ubah'])) {
    $mhs_NPM = $_POST['npmMHS'];
    $peserta_SEMT = $_POST['semester'];
    $peserta_THAKD = $_POST['thakd'];
    $peserta_TGLDAFTAR = $_POST['tgl_daftar'];
    $peserta_JUDUL = $_POST['judul'];
    
    $peserta_DOKUMEN = $_FILES['dokumen']['name'];
    $dokumen_tmp = $_FILES['dokumen']['tmp_name'];

    if (empty($peserta_DOKUMEN)) {
        $peserta_DOKUMEN = $row_edit['peserta_DOKUMEN'];
    } else {
        move_uploaded_file($dokumen_tmp, 'images/' . $peserta_DOKUMEN);
    }

    mysqli_query($conn, "UPDATE pesertaskripsi SET 
        mhs_NPM='$mhs_NPM', peserta_SEMT='$peserta_SEMT', peserta_THAKD='$peserta_THAKD',
        peserta_TGLDAFTAR='$peserta_TGLDAFTAR', peserta_JUDUL='$peserta_JUDUL', peserta_DOKUMEN='$peserta_DOKUMEN'
        WHERE mhs_NPM='$NPM'");

    header("location: inputpesertaskripsi.php");
}
?>

<body class="sb-nav-fixed">
<?php include "bagiankode/menunav.php"; ?>

<div id="layoutSidenav">
    <?php include "bagiankode/menu.php"; ?>

    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Edit Peserta Skripsi</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Dashboard / Edit Peserta Skripsi</li>
                </ol>

                <!-- FORM EDIT -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">Form Edit Peserta Skripsi</div>
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data">

                            <div class="mb-3">
                                <label>NPM Mahasiswa</label>
                                <select class="form-control" id="npmMHS" name="npmMHS" required>
                                    <option value="<?= $row_edit['mhs_NPM']; ?>" selected>
                                        <?= $row_edit_mhs["mhs_NPM"] ?? $row_edit['mhs_NPM']; ?> - 
                                        <?= $row_edit_mhs["mhs_Nama"] ?? 'Nama Tidak Ditemukan'; ?> (Saat Ini)
                                    </option>
                                    <?php while ($row_mhs = mysqli_fetch_assoc($datamhs)) { 
                                        if($row_mhs["mhs_NPM"] == $row_edit['mhs_NPM']) continue; ?>
                                        <option value="<?= $row_mhs["mhs_NPM"]; ?>">
                                            <?= $row_mhs["mhs_NPM"]; ?> - <?= $row_mhs["mhs_Nama"]; ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label>Semester</label>
                                <select class="form-control" name="semester">
                                    <option value="Ganjil" <?= ($row_edit['peserta_SEMT']=='Ganjil')?'selected':''; ?>>Ganjil</option>
                                    <option value="Genap" <?= ($row_edit['peserta_SEMT']=='Genap')?'selected':''; ?>>Genap</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label>Tahun Akademik</label>
                                <input type="text" class="form-control" name="thakd" value="<?= $row_edit["peserta_THAKD"]; ?>">
                            </div>

                            <div class="mb-3">
                                <label>Tanggal Daftar</label>
                                <input type="date" class="form-control" name="tgl_daftar" value="<?= $row_edit["peserta_TGLDAFTAR"]; ?>">
                            </div>

                            <div class="mb-3">
                                <label>Judul Skripsi</label>
                                <input type="text" class="form-control" name="judul" value="<?= $row_edit["peserta_JUDUL"]; ?>">
                            </div>

                            <div class="mb-3">
                                <label>Unggah Dokumen (Gambar)</label>
                                <input type="file" class="form-control" name="dokumen">
                                <small class="text-muted">Dokumen saat ini: <strong><?= $row_edit["peserta_DOKUMEN"]; ?></strong><br>
                                Biarkan kosong jika tidak ingin mengganti gambar</small>
                            </div>

                            <button type="submit" name="Ubah" class="btn btn-success">Ubah Data</button>
                            <a href="inputpesertaskripsi.php" class="btn btn-danger">Batal</a>
                        </form>
                    </div>
                </div>

                <!-- TABEL PESERTA LAIN -->
                <div class="card mb-4">
                    <div class="card-header bg-dark text-white">Daftar Peserta Skripsi Lainnya</div>
                    <div class="card-body table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-success">
                                <tr>
                                    <th>NPM</th>
                                    <th>Nama Mahasiswa</th>
                                    <th>Semester</th>
                                    <th>Tahun Akd.</th>
                                    <th>Tgl. Daftar</th>
                                    <th>Judul</th>
                                    <th>Dokumen</th>
                                    <th colspan="2" class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php while ($row = mysqli_fetch_assoc($query_display)) { ?>
                                <tr>
                                    <td><?= $row['mhs_NPM']; ?></td>
                                    <td><?= $row['mhs_Nama']; ?></td>
                                    <td><?= $row['peserta_SEMT']; ?></td>
                                    <td><?= $row['peserta_THAKD']; ?></td>
                                    <td><?= $row['peserta_TGLDAFTAR']; ?></td>
                                    <td><?= $row['peserta_JUDUL']; ?></td>
                                    <td>
                                        <?php if (empty($row['peserta_DOKUMEN'])) { echo "<span class='text-muted'>No Image</span>"; }
                                        else { ?>
                                            <img src="images/<?= $row['peserta_DOKUMEN']; ?>" width="80" class="img-thumbnail">
                                        <?php } ?>
                                    </td>
                                    <td>
                                    <a href="editpesertaskripsi.php?ubah=<?php echo $row['mhs_NPM']; ?>" class="btn btn-success btn-sm">Edit</a>
                                </td>
                                <td>
                                    <a href="inputpesertaskripsi.php?hapus=<?php echo $row['mhs_NPM']; ?>" 
                                    class="btn btn-danger btn-sm" 
                                    onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </main>

        <?php include "bagiankode/footer.php"; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/js/select2.min.js"></script>
<script>
$(document).ready(function(){
    $('#npmMHS').select2();
});
</script>
</body>
</html>
