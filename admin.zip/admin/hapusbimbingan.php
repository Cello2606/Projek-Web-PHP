<?php
include("includes/config.php");

$npm = $_GET['npm'];
$nidn = $_GET['nidn'];
$tgl = $_GET['tgl'];

mysqli_query($conn, "
    DELETE FROM bimbinganskripsi 
    WHERE mhs_NPM='$npm' 
    AND dosen_NIDN='$nidn'
    AND TGL_bimbingan='$tgl'
");

echo "<script>alert('Data bimbingan berhasil dihapus');location='inputbimbingan.php';</script>";
?>
