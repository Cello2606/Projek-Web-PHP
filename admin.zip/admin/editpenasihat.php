<?php
include("includes/config.php");

ob_start();
session_start();
if (!isset($_SESSION['useremail'])) {
    header("location:login.php");
    exit;
}

// ==================== GET NPM ====================
if (!isset($_GET["ubahpenasihat"])) {
    echo "<script>alert('Parameter tidak valid');location='inputpenasihat.php';</script>";
    exit;
}

$NPM = $_GET["ubahpenasihat"];

// Ambil data penasihat yang mau diedit
$edit = mysqli_query($conn, "
    SELECT penasihat.*, 
           mahasiswa.mhs_Nama,
           dosen.dosen_Nama
    FROM penasihat 
    JOIN mahasiswa ON mahasiswa.mhs_NPM = penasihat.mhs_NPM
    JOIN dosen ON dosen.dosen_NIDN = penasihat.dosen_NIDN
    WHERE penasihat.mhs_NPM = '$NPM'
");
$row = mysqli_fetch_assoc($edit);

if (!$row) {
    echo "<script>alert('Data tidak ditemukan');location='inputpenasihat.php';</script>";
    exit;
}

// Dropdown data
$datamhs   = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY mhs_Nama ASC");
$datadosen = mysqli_query($conn, "SELECT * FROM dosen ORDER BY dosen_Nama ASC");

// ==================== UPDATE DATA ====================
if (isset($_POST['Ubah'])) {

    $npm_baru  = $_POST['npmMHS'];
    $nidn_baru = $_POST['nidnDOSEN'];
    $ket       = $_POST['penasihatKET'];

    // Upload file
    $file = $_FILES['penasihatFILE']['name'];
    $tmp  = $_FILES['penasihatFILE']['tmp_name'];

    if ($file != "") {
        // optional: bisa ditambah validasi ekstensi (jpg/png/pdf dll)
        move_uploaded_file($tmp, "images/" . $file);
    } else {
        $file = $row['penasihat_FILE']; // gunakan file lama
    }

    mysqli_query($conn, "
        UPDATE penasihat SET 
            mhs_NPM        = '$npm_baru',
            dosen_NIDN     = '$nidn_baru',
            penasihat_FILE = '$file',
            penasihat_KET  = '$ket'
        WHERE mhs_NPM = '$NPM'
    ");

    echo "<script>alert('Data berhasil diupdate');location='inputpenasihat.php';</script>";
    exit;
}

// ==================== DATA UNTUK TABEL ====================
$list_penasihat = mysqli_query($conn, "
    SELECT penasihat.*,
           mahasiswa.mhs_Nama,
           dosen.dosen_Nama
    FROM penasihat
    JOIN mahasiswa ON mahasiswa.mhs_NPM = penasihat.mhs_NPM
    JOIN dosen ON dosen.dosen_NIDN = penasihat.dosen_NIDN
    ORDER BY mahasiswa.mhs_Nama ASC
");
?>

<!DOCTYPE html>
<html>
    <?php include "bagiankode/head.php"; ?>
<body class="sb-nav-fixed">

<?php include "bagiankode/menunav.php"; ?>

<div id="layoutSidenav">

    <?php include "bagiankode/menu.php"; ?>

    <div id="layoutSidenav_content">
        <main>

            <div class="container-fluid px-4">

                <h1 class="mt-4">Edit Penasihat Akademik</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="inputpenasihat.php">Penasihat Akademik</a></li>
                    <li class="breadcrumb-item active">Edit Penasihat</li>
                </ol>

                <!-- ================= FORM EDIT ================= -->
                <div class="card mb-4">
                    <div class="card-header bg-warning fw-bold">
                        Form Edit Penasihat
                    </div>

                    <div class="card-body">

                        <form method="POST" enctype="multipart/form-data">

                            <!-- NPM -->
                            <div class="mb-3">
                                <label>NPM Mahasiswa</label>
                                <select class="form-control" name="npmMHS" id="npmMHS" required>
                                    <!-- Pilihan current -->
                                    <option value="<?= $row['mhs_NPM']; ?>">
                                        <?= $row['mhs_NPM']; ?> - <?= $row['mhs_Nama']; ?> (Saat ini)
                                    </option>

                                    <?php while($m = mysqli_fetch_assoc($datamhs)) { ?>
                                        <option value="<?= $m['mhs_NPM']; ?>">
                                            <?= $m['mhs_NPM']; ?> - <?= $m['mhs_Nama']; ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>

                            <!-- NIDN -->
                            <div class="mb-3">
                                <label>Dosen Pembimbing</label>
                                <select class="form-control" name="nidnDOSEN" id="nidnDOSEN" required>
                                    <!-- Pilihan current -->
                                    <option value="<?= $row['dosen_NIDN']; ?>">
                                        <?= $row['dosen_NIDN']; ?> - <?= $row['dosen_Nama']; ?> (Saat ini)
                                    </option>

                                    <?php while($d = mysqli_fetch_assoc($datadosen)) { ?>
                                        <option value="<?= $d['dosen_NIDN']; ?>">
                                            <?= $d['dosen_NIDN']; ?> - <?= $d['dosen_Nama']; ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>

                            <!-- FILE -->
                            <div class="mb-3">
                                <label>Dokumen</label><br>

                                <?php if ($row['penasihat_FILE'] != "") { ?>
                                    <img src="images/<?= $row['penasihat_FILE']; ?>" width="100" class="mb-2"><br>
                                <?php } else { ?>
                                    <span class="text-muted">Belum ada file tersimpan.</span><br>
                                <?php } ?>

                                <input type="file" class="form-control" name="penasihatFILE">
                                <small class="text-muted">Kosongkan jika tidak ingin mengubah file.</small>
                            </div>

                            <!-- KETERANGAN -->
                            <div class="mb-3">
                                <label>Keterangan</label>
                                <input type="text" class="form-control" name="penasihatKET"
                                    value="<?= $row['penasihat_KET']; ?>">
                            </div>

                            <button class="btn btn-success" name="Ubah">Update</button>
                            <a href="inputpenasihat.php" class="btn btn-secondary">Kembali</a>

                        </form>
                    </div>
                </div>

                <!-- ================= TABEL PENASIHAT ================= -->
                <div class="card mb-4">
                    <div class="card-header bg-dark text-white">
                        Data Penasihat Akademik
                    </div>

                    <div class="card-body">
                        <table class="table table-striped table-success table-hover">
                            <thead>
                                <tr>
                                    <th>NPM</th>
                                    <th>Nama Mahasiswa</th>
                                    <th>NIDN</th>
                                    <th>Nama Dosen</th>
                                    <th>Dokumen</th>
                                    <th>Keterangan</th>
                                    <th style="text-align:center;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($p = mysqli_fetch_assoc($list_penasihat)) { ?>
                                    <tr>
                                        <td><?= $p['mhs_NPM']; ?></td>
                                        <td><?= $p['mhs_Nama']; ?></td>
                                        <td><?= $p['dosen_NIDN']; ?></td>
                                        <td><?= $p['dosen_Nama']; ?></td>
                                        <td>
                                            <?php if ($p['penasihat_FILE'] != "") { ?>
                                                <img src="images/<?= $p['penasihat_FILE']; ?>" width="60">
                                            <?php } else { ?>
                                                <span class="text-muted">Tidak ada</span>
                                            <?php } ?>
                                        </td>
                                        <td><?= $p['penasihat_KET']; ?></td>

                                        <td style="text-align:center;">
                                            <div class="btn-group" role="group" aria-label="Aksi">
                                                <a href="editpenasihat.php?ubahpenasihat=<?= $p['mhs_NPM']; ?>"
                                                   class="btn btn-warning btn-sm">Edit</a>

                                                <a href="hapuspenasihat.php?hapuspenasihat=<?= $p['mhs_NPM']; ?>"
                                                   class="btn btn-danger btn-sm"
                                                   onclick="return confirm('Yakin ingin menghapus data ini?');">
                                                    Hapus
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>

        </main>

        <?php include "bagiankode/footer.php"; ?>

    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/js/select2.min.js"></script>
<script>
$(document).ready(function() {
    $('#npmMHS').select2();
    $('#nidnDOSEN').select2();
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>