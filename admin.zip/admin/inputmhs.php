<!DOCTYPE html>
<html>
    <?php
include "bagiankode/head.php";
?>
<?php
ob_start();
session_start();
if(!isset($_SESSION['useremail']))
header("location:login.php");
?>
<body class="sb-nav-fixed">
<?php
include "bagiankode/menunav.php";
?>
    <div id="layoutSidenav">
        <?php
include "bagiankode/menu.php";
?>

<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">

    <h1 class="mt-4">Input Mahasiswa</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Mahasiswa</li>
    </ol>

<?php
include("includes/config.php");

// PROSES SIMPAN
if (isset($_POST['Simpan'])) {

    $mhs_NPM    = $_POST['npmMHS'];
    $mhs_Nama   = $_POST['namaMHS'];
    $mhs_Alamat = $_POST['alamatMHS'];
    $mhs_DOB    = $_POST['lahirMHS'];
    $mhs_Ket    = $_POST['ketMHS'];

    // Validasi minimal input
    if (empty($mhs_NPM) || empty($mhs_Nama)) {
        echo "<script>alert('NPM dan Nama wajib diisi');</script>";
    } else {

        mysqli_query($conn, "
            INSERT INTO mahasiswa
            (mhs_NPM, mhs_Nama, mhs_alamat, mhs_DOB, mhs_Ket)
            VALUES ('$mhs_NPM', '$mhs_Nama', '$mhs_Alamat', '$mhs_DOB', '$mhs_Ket')
        ");

        echo "<script>alert('Data mahasiswa berhasil disimpan');location='inputmhs.php';</script>";
    }
}

// QUERY DATA MAHASISWA
$query = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY mhs_NPM ASC");
?>

<!-- FORM INPUT -->
<div class="row">
<div class="col-1"></div>
<div class="col-10">

    <form method="POST">

        <div class="row mb-3 mt-4">
            <label class="col-sm-2 col-form-label">NPM Mahasiswa</label>
            <div class="col-sm-10">
                <input type="text" maxlength="9" class="form-control"
                       id="npmMHS" name="npmMHS" placeholder="Nomor Pokok Mahasiswa" required>
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Nama Mahasiswa</label>
            <div class="col-sm-10">
                <input type="text" class="form-control"
                       id="namaMHS" name="namaMHS" placeholder="Isikan Nama Mahasiswa" required>
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Alamat Mahasiswa</label>
            <div class="col-sm-10">
                <input type="text" class="form-control"
                       id="alamatMHS" name="alamatMHS" placeholder="Isikan Alamat Mahasiswa">
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Tanggal Lahir</label>
            <div class="col-sm-10">
                <input type="date" class="form-control"
                       id="lahirMHS" name="lahirMHS">
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Keterangan</label>
            <div class="col-sm-10">
                <input type="text" class="form-control"
                       id="ketMHS" name="ketMHS" placeholder="Keterangan tambahan (opsional)">
            </div>
        </div>

        <div class="form-group row mb-4">
            <div class="col-sm-2"></div>
            <div class="col-sm-10">
                <button type="submit" class="btn btn-success" name="Simpan">Simpan</button>
                <button type="reset" class="btn btn-danger">Batal</button>
            </div>
        </div>

    </form>

</div>
<div class="col-1"></div>
</div>

<!-- TABEL MAHASISWA -->
<div class="row mt-5">
<div class="col-1"></div>
<div class="col-10">

    <div class="jumbotron mb-3">
        <h3 class="display-6">Daftar Mahasiswa</h3>
    </div>

    <table class="table table-striped table-success table-hover">
        <thead>
            <tr>
                <th>NPM</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Tgl Lahir</th>
                <th>Keterangan</th>
                <th style="text-align:center;">Aksi</th>
            </tr>
        </thead>

        <tbody>
        <?php while ($row = mysqli_fetch_array($query)) { ?>
            <tr>
                <td><?= $row['mhs_NPM']; ?></td>
                <td><?= $row['mhs_Nama']; ?></td>
                <td><?= $row['mhs_Alamat']; ?></td>
                <td><?= $row['mhs_DOB']; ?></td>
                <td><?= $row['mhs_Ket']; ?></td>

                <td style="text-align:center;">
                    <a href="editmhs.php?npm=<?= $row['mhs_NPM']; ?>"
                       class="btn btn-warning btn-sm">Edit</a>

                    <a href="hapusmhs.php?npm=<?= $row['mhs_NPM']; ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Yakin ingin menghapus?');">
                        Hapus
                    </a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>

</div>
<div class="col-1"></div>
</div>

</div>
</main>

<?php include "bagiankode/footer.php"; ?>

</div>
</div>

<?php include "bagiankode/footer.php"; ?>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>

</html>
