
<?php
$teks = "Latihan 1";
$bilang1 = 35;
$bilang2 = $bilang1 + 30;
echo "$teks<br>";
echo "Jumlah Bilangan = $bilang2<br>";
echo "<br>";
?>

<?php
function FA() {
$F = "Test1 ";
$A = "Test2 <br>";
$FA = "$F + $A";
echo $F,"<br>";
echo $A,"<br>";
echo "Gabungan F dan A = $F + $A";
echo "Hasil penjumlahan F dan A = $FA";
}
FA();
$F = 10;
$A = 25;
$FA = $F + $A;
echo "Hasil penjumlahan F dan A = $FA<br>";
?>

<?php
$nilai = 72;

if ($nilai > 79){
    $grade = "A";
} elseif ($nilai > 69){
    $grade = "B";
} else if ($nilai > 55){
    $grade = "C";
} else {
    $grade = "D";
}

echo "<br>";

echo "Nilai Angka: $nilai<br>";
echo "Nilai Huruf: $grade";
?>