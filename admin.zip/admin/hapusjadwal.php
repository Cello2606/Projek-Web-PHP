<?php

include "includes/config.php"; 


if(isset($_GET['hapusjadwal']))
{
  
    $NPM = $_GET["hapusjadwal"]; 
    

    mysqli_query($conn, "DELETE FROM jadwalskripsi WHERE mhs_NPM = '$NPM'");
    
    
    echo "<script>alert('DATA BERHASIL DIHAPUS');";
    echo "document.location='inputjadwal.php'</script>";
}
?>