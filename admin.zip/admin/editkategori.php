<?php
ob_start();
session_start();
if (!isset($_SESSION['useremail'])) {
    header("location:login.php");
    exit;
}

include("includes/config.php");

// ====================== AMBIL PARAMETER KUNCI DARI URL ======================
if (
    !isset($_GET['npm']) ||
    !isset($_GET['nidn']) ||
    !isset($_GET['kategori'])
) {
    echo "<script>alert('Parameter tidak lengkap');location='inputkategori.php';</script>";
    exit;
}

$npm_lama      = $_GET['npm'];
$nidn_lama     = $_GET['nidn'];
$kategori_lama = $_GET['kategori']; // sudah otomatis di-decode oleh PHP

// ====================== AMBIL DATA KATEGORI YANG MAU DIEDIT ======================
$q_kategori = mysqli_query($conn, "
    SELECT kategoriskripsi.*,
           mahasiswa.mhs_Nama,
           dosen.dosen_Nama
    FROM kategoriskripsi
    JOIN mahasiswa ON mahasiswa.mhs_NPM = kategoriskripsi.mhs_NPM
    JOIN dosen     ON dosen.dosen_NIDN = kategoriskripsi.dosen_NIDN
    WHERE kategoriskripsi.mhs_NPM       = '$npm_lama'
      AND kategoriskripsi.dosen_NIDN    = '$nidn_lama'
      AND kategoriskripsi.nama_KATEGORI = '$kategori_lama'
");

$data_kategori = mysqli_fetch_assoc($q_kategori);

if (!$data_kategori) {
    echo "<script>alert('Data kategori tidak ditemukan');location='inputkategori.php';</script>";
    exit;
}

// ====================== DATA UNTUK DROPDOWN ======================
$q_mhs   = mysqli_query($conn, "SELECT mhs_NPM, mhs_Nama FROM mahasiswa ORDER BY mhs_Nama ASC");
$q_dosen = mysqli_query($conn, "SELECT dosen_NIDN, dosen_Nama FROM dosen ORDER BY dosen_Nama ASC");

// ====================== PROSES UPDATE ======================
if (isset($_POST['update'])) {

    $mhs_NPM_baru       = $_POST['npmMHS'];
    $dosen_NIDN_baru    = $_POST['nidnDOSEN'];
    $nama_KATEGORI_baru = $_POST['namaKATEGORI'];
    $ket_KATEGORI_baru  = $_POST['ketKATEGORI'];

    if (empty($mhs_NPM_baru) || empty($dosen_NIDN_baru) || empty($nama_KATEGORI_baru)) {
        echo "<script>alert('NPM, Dosen, dan Nama Kategori wajib diisi');</script>";
    } else {

        mysqli_query($conn, "
            UPDATE kategoriskripsi SET
                mhs_NPM       = '$mhs_NPM_baru',
                dosen_NIDN    = '$dosen_NIDN_baru',
                nama_KATEGORI = '$nama_KATEGORI_baru',
                ket_KATEGORI  = '$ket_KATEGORI_baru'
            WHERE mhs_NPM       = '$npm_lama'
              AND dosen_NIDN    = '$nidn_lama'
              AND nama_KATEGORI = '$kategori_lama'
        ");

        echo "<script>alert('Data kategori skripsi berhasil diupdate');location='inputkategori.php';</script>";
        exit;
    }
}

// ====================== DATA UNTUK TABEL DI BAWAH ======================
$query = mysqli_query($conn, "
    SELECT kategoriskripsi.*,
           mahasiswa.mhs_Nama,
           dosen.dosen_Nama
    FROM kategoriskripsi
    JOIN mahasiswa ON mahasiswa.mhs_NPM = kategoriskripsi.mhs_NPM
    JOIN dosen     ON dosen.dosen_NIDN = kategoriskripsi.dosen_NIDN
    ORDER BY kategoriskripsi.nama_KATEGORI ASC
");
?>

<!DOCTYPE html>
<html>
    <?php
    include "bagiankode/head.php";
    ?>
<body class="sb-nav-fixed">
<?php
include "bagiankode/menunav.php";
?>
<div id="layoutSidenav">
    <?php
    include "bagiankode/menu.php";
    ?>

    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">

                <h1 class="mt-4">Edit Kategori Skripsi</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="inputkategori.php">Kategori Skripsi</a></li>
                    <li class="breadcrumb-item active">Edit Kategori Skripsi</li>
                </ol>

                <!-- FORM EDIT -->
                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-10">

                        <form method="POST" class="mb-4">

                            <!-- simpan kunci lama -->
                            <input type="hidden" name="npm_lama"      value="<?= $npm_lama; ?>">
                            <input type="hidden" name="nidn_lama"     value="<?= $nidn_lama; ?>">
                            <input type="hidden" name="kategori_lama" value="<?= htmlspecialchars($kategori_lama); ?>">

                            <div class="row mb-3 mt-4">
                                <label class="col-sm-2 col-form-label">Mahasiswa</label>
                                <div class="col-sm-10">
                                    <select class="form-select" id="npmMHS" name="npmMHS" required>
                                        <option value="">-- Pilih Mahasiswa --</option>
                                        <?php while($m = mysqli_fetch_assoc($q_mhs)) { ?>
                                            <option value="<?= $m['mhs_NPM']; ?>"
                                                <?= ($m['mhs_NPM'] == $data_kategori['mhs_NPM']) ? 'selected' : ''; ?>>
                                                <?= $m['mhs_Nama']; ?> (<?= $m['mhs_NPM']; ?>)
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Dosen Pembimbing/Penguji</label>
                                <div class="col-sm-10">
                                    <select class="form-select" id="nidnDOSEN" name="nidnDOSEN" required>
                                        <option value="">-- Pilih Dosen --</option>
                                        <?php while($d = mysqli_fetch_assoc($q_dosen)) { ?>
                                            <option value="<?= $d['dosen_NIDN']; ?>"
                                                <?= ($d['dosen_NIDN'] == $data_kategori['dosen_NIDN']) ? 'selected' : ''; ?>>
                                                <?= $d['dosen_Nama']; ?> (<?= $d['dosen_NIDN']; ?>)
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Nama Kategori</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control"
                                           id="namaKATEGORI" name="namaKATEGORI"
                                           value="<?= htmlspecialchars($data_kategori['nama_KATEGORI']); ?>"
                                           placeholder="Contoh: Eksperimen, Studi Kasus, Kualitatif" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Keterangan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control"
                                           id="ketKATEGORI" name="ketKATEGORI"
                                           value="<?= htmlspecialchars($data_kategori['ket_KATEGORI']); ?>"
                                           placeholder="Keterangan tambahan (opsional)">
                                </div>
                            </div>

                            <div class="form-group row mb-4">
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-success" name="update">Simpan Perubahan</button>
                                    <a href="inputkategori.php" class="btn btn-secondary">Kembali</a>
                                </div>
                            </div>

                        </form>

                    </div>
                    <div class="col-1"></div>
                </div>

                <!-- TABEL KATEGORI SKRIPSI -->
                <div class="row mt-3">
                    <div class="col-1"></div>
                    <div class="col-10">

                        <div class="jumbotron mb-3">
                            <h3 class="display-6">Daftar Kategori Skripsi</h3>
                        </div>

                        <table class="table table-striped table-success table-hover">
                            <thead>
                                <tr>
                                    <th>NPM</th>
                                    <th>Nama Mahasiswa</th>
                                    <th>NIDN</th>
                                    <th>Nama Dosen</th>
                                    <th>Nama Kategori</th>
                                    <th>Keterangan</th>
                                    <th style="text-align:center;">Aksi</th>
                                </tr>
                            </thead>

                            <tbody>
                            <?php while ($row = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?= $row['mhs_NPM']; ?></td>
                                    <td><?= $row['mhs_Nama']; ?></td>
                                    <td><?= $row['dosen_NIDN']; ?></td>
                                    <td><?= $row['dosen_Nama']; ?></td>
                                    <td><?= $row['nama_KATEGORI']; ?></td>
                                    <td><?= $row['ket_KATEGORI']; ?></td>

                                    <td style="text-align:center;">
                                        <a href="editkategori.php?npm=<?= $row['mhs_NPM']; ?>&nidn=<?= $row['dosen_NIDN']; ?>&kategori=<?= urlencode($row['nama_KATEGORI']); ?>"
                                           class="btn btn-warning btn-sm">Edit</a>

                                        <a href="hapuskategori.php?hapuskategori=<?= $row['mhs_NPM']; ?>&nidn=<?= $row['dosen_NIDN']; ?>&kategori=<?= urlencode($row['nama_KATEGORI']); ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Yakin ingin menghapus?');">
                        Hapus
                    </a>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>

                    </div>
                    <div class="col-1"></div>
                </div>

            </div>
        </main>

        <?php include "bagiankode/footer.php"; ?>

    </div>
</div>

<?php include "bagiankode/jsscript.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>