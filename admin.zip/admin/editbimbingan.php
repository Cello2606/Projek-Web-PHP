<!DOCTYPE html>
<html>
    <?php
include "bagiankode/head.php";
?>
<?php
ob_start();
session_start();
if(!isset($_SESSION['useremail']))
header("location:login.php");
?>
<body class="sb-nav-fixed">
<?php
include "bagiankode/menunav.php";
?>
    <div id="layoutSidenav">
        <?php
include "bagiankode/menu.php";
?>

<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">

    <h1 class="mt-4">Edit Bimbingan</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="inputbimbingan.php">Bimbingan</a></li>
        <li class="breadcrumb-item active">Edit Bimbingan</li>
    </ol>

<?php
include("includes/config.php");

// =============================== AMBIL DATA LAMA ===============================
// parameter dari inputbimbingan.php: npm, nidn, tgl
if (!isset($_GET['npm']) || !isset($_GET['nidn']) || !isset($_GET['tgl'])) {
    echo "<script>alert('Data tidak valid');location='inputbimbingan.php';</script>";
    exit;
}

$npm_lama  = $_GET['npm'];
$nidn_lama = $_GET['nidn'];
$tgl_lama  = $_GET['tgl'];

// ambil data bimbingan berdasarkan kunci lama
$q_bimbingan = mysqli_query($conn, "
    SELECT * FROM bimbinganskripsi
    WHERE mhs_NPM = '$npm_lama'
      AND dosen_NIDN = '$nidn_lama'
      AND TGL_bimbingan = '$tgl_lama'
");

$data_bimbingan = mysqli_fetch_assoc($q_bimbingan);

if (!$data_bimbingan) {
    echo "<script>alert('Data bimbingan tidak ditemukan');location='inputbimbingan.php';</script>";
    exit;
}

// data untuk dropdown
$datamhs   = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY mhs_Nama ASC");
$datadosen = mysqli_query($conn, "SELECT * FROM dosen ORDER BY dosen_Nama ASC");

// =============================== PROSES UPDATE ===============================
if (isset($_POST['update'])) {

    $npm_baru  = $_POST['npmMHS'];
    $nidn_baru = $_POST['nidnDOSEN'];
    $tgl_baru  = $_POST['tgl'];
    $isi_baru  = $_POST['isi'];

    $dokumen_lama = $_POST['dokumen_lama'];

    // upload dokumen baru (opsional)
    $file_baru = $_FILES['dokumen']['name'];
    $tmp_baru  = $_FILES['dokumen']['tmp_name'];

    if ($file_baru != "") {

        $ext = strtolower(pathinfo($file_baru, PATHINFO_EXTENSION));
        if ($ext != "pdf") {
            echo "<script>alert('File harus PDF');</script>";
        } else {

            if (!is_dir("uploads")) mkdir("uploads");

            // bisa ditambah uniqid kalau mau aman
            move_uploaded_file($tmp_baru, "uploads/" . $file_baru);

            $nama_dokumen = $file_baru;
        }
    } else {
        // kalau tidak upload baru, pakai yang lama
        $nama_dokumen = $dokumen_lama;
    }

    // update data berdasarkan kunci lama (supaya boleh ganti npm/nidn/tgl)
    mysqli_query($conn, "
        UPDATE bimbinganskripsi SET
            mhs_NPM       = '$npm_baru',
            dosen_NIDN    = '$nidn_baru',
            TGL_bimbingan = '$tgl_baru',
            ISI_bimbingan = '$isi_baru',
            dokumen       = '$nama_dokumen'
        WHERE mhs_NPM = '$npm_lama'
          AND dosen_NIDN = '$nidn_lama'
          AND TGL_bimbingan = '$tgl_lama'
    ");

    echo "<script>alert('Data bimbingan berhasil diupdate');location='inputbimbingan.php';</script>";
    exit;
}

// =============================== DATA UNTUK TABEL DI BAWAH ===============================
$data = mysqli_query($conn, "
    SELECT * FROM bimbinganskripsi
    JOIN mahasiswa ON mahasiswa.mhs_NPM = bimbinganskripsi.mhs_NPM
    JOIN dosen ON dosen.dosen_NIDN = bimbinganskripsi.dosen_NIDN
    WHERE 1=1
    ORDER BY bimbinganskripsi.TGL_bimbingan DESC
");
?>

<!-- FORM EDIT BIMBINGAN -->
<div class="card mb-4">
    <div class="card-header bg-warning text-dark">Edit Bimbingan Skripsi</div>
    <div class="card-body">

        <form method="POST" enctype="multipart/form-data">

            <!-- simpan kunci lama & dokumen lama -->
            <input type="hidden" name="npm_lama"  value="<?= $npm_lama; ?>">
            <input type="hidden" name="nidn_lama" value="<?= $nidn_lama; ?>">
            <input type="hidden" name="tgl_lama"  value="<?= $tgl_lama; ?>">
            <input type="hidden" name="dokumen_lama" value="<?= $data_bimbingan['dokumen']; ?>">

            <div class="mb-3">
                <label>NPM Mahasiswa</label>
                <select class="form-control" name="npmMHS" required>
                    <option value="">-- Pilih Mahasiswa --</option>
                    <?php while($m = mysqli_fetch_assoc($datamhs)) { ?>
                        <option value="<?= $m['mhs_NPM']; ?>"
                            <?= ($m['mhs_NPM'] == $data_bimbingan['mhs_NPM']) ? 'selected' : ''; ?>>
                            <?= $m['mhs_NPM']; ?> - <?= $m['mhs_Nama']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Dosen Pembimbing</label>
                <select class="form-control" name="nidnDOSEN" required>
                    <option value="">-- Pilih Dosen --</option>
                    <?php while($d = mysqli_fetch_assoc($datadosen)) { ?>
                        <option value="<?= $d['dosen_NIDN']; ?>"
                            <?= ($d['dosen_NIDN'] == $data_bimbingan['dosen_NIDN']) ? 'selected' : ''; ?>>
                            <?= $d['dosen_NIDN']; ?> - <?= $d['dosen_Nama']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Tanggal Bimbingan</label>
                <input type="date" class="form-control" name="tgl"
                       value="<?= $data_bimbingan['TGL_bimbingan']; ?>" required>
            </div>

            <div class="mb-3">
                <label>Isi Bimbingan</label>
                <textarea class="form-control" name="isi" rows="3" required><?= $data_bimbingan['ISI_bimbingan']; ?></textarea>
            </div>

            <div class="mb-3">
                <label>Dokumen Saat Ini</label><br>
                <?php if ($data_bimbingan['dokumen'] == "") { ?>
                    <span class="text-danger">Tidak ada file</span>
                <?php } else { ?>
                    <a href="uploads/<?= $data_bimbingan['dokumen']; ?>" class="btn btn-sm btn-primary" target="_blank">
                        Lihat PDF Lama
                    </a>
                <?php } ?>
            </div>

            <div class="mb-3">
                <label>Upload Dokumen Baru (PDF) <small class="text-muted">(opsional)</small></label>
                <input type="file" class="form-control" name="dokumen" accept="application/pdf">
                <small class="text-muted">Kosongkan jika tidak ingin mengganti file.</small>
            </div>

            <button class="btn btn-success" name="update">Simpan Perubahan</button>
            <a href="inputbimbingan.php" class="btn btn-secondary">Kembali</a>

        </form>

    </div>
</div>

<!-- TABEL DATA BIMBINGAN (SAMA SEPERTI DI inputbimbingan.php) -->
<div class="card mb-4">
    <div class="card-header bg-dark text-white">Data Bimbingan Skripsi</div>
    <div class="card-body">

        <table class="table table-bordered table-striped">
            <thead class="table-success">
                <tr>
                    <th>NPM</th>
                    <th>Nama</th>
                    <th>Dosen</th>
                    <th>Tanggal</th>
                    <th>Isi</th>
                    <th>Dokumen</th>
                    <th width="150px">Aksi</th>
                </tr>
            </thead>

            <tbody>
            <?php while ($b = mysqli_fetch_assoc($data)) { ?>
                <tr>
                    <td><?= $b['mhs_NPM']; ?></td>
                    <td><?= $b['mhs_Nama']; ?></td>
                    <td><?= $b['dosen_Nama']; ?></td>
                    <td><?= $b['TGL_bimbingan']; ?></td>
                    <td><?= $b['ISI_bimbingan']; ?></td>

                    <td>
                        <?php if ($b['dokumen'] == "") { ?>
                            <span class="text-danger">Tidak ada file</span>
                        <?php } else { ?>
                            <a href="uploads/<?= $b['dokumen']; ?>" class="btn btn-sm btn-primary" target="_blank">PDF</a>
                        <?php } ?>
                    </td>

                    <td>
                        <a href="editbimbingan.php?npm=<?= $b['mhs_NPM']; ?>&nidn=<?= $b['dosen_NIDN']; ?>&tgl=<?= $b['TGL_bimbingan']; ?>"
                           class="btn btn-warning btn-sm">Edit</a>

                        <a onclick="return confirm('Hapus data?')" 
                           href="hapusbimbingan.php?npm=<?= $b['mhs_NPM']; ?>&nidn=<?= $b['dosen_NIDN']; ?>&tgl=<?= $b['TGL_bimbingan']; ?>"
                           class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>

        </table>

    </div>
</div>

</div>
</main>

<?php include "bagiankode/footer.php"; ?>

</div>
</div>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</html>