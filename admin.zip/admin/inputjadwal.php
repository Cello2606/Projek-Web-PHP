<!DOCTYPE html>
<html>
    <?php
include "bagiankode/head.php";
?>
<?php
ob_start();
session_start();
if(!isset($_SESSION['useremail']))
header("location:login.php");
?>
<body class="sb-nav-fixed">
<?php
include "bagiankode/menunav.php";
?>
    <div id="layoutSidenav">
        <?php
include "bagiankode/menu.php";
?>

<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">

    <h1 class="mt-4">Input Jadwal Skripsi</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Jadwal Skripsi</li>
    </ol>

<?php
include("includes/config.php");

// PROSES SIMPAN
if (isset($_POST['Simpan'])) {

    $mhs_NPM         = $_POST['npmMHS'];
    $dosen_NIDN      = $_POST['nidnDOSEN'];
    $waktu_SKRIPSI   = $_POST['waktuSKRIPSI'];
    $tanggal_SKRIPSI = $_POST['tglSKRIPSI'];
    $tempat_SKRIPSI  = $_POST['tempatSKRIPSI'];
    $ruangan_SKRIPSI = $_POST['ruanganSKRIPSI'];

    // Validasi minimal input
    if (empty($mhs_NPM) || empty($dosen_NIDN) || empty($tanggal_SKRIPSI) || empty($waktu_SKRIPSI)) {
        echo "<script>alert('NPM, Dosen, Tanggal dan Waktu wajib diisi');</script>";
    } else {

        mysqli_query($conn, "
            INSERT INTO jadwalskripsi
            (mhs_NPM, dosen_NIDN, waktu_SKRIPSI, tanggal_SKRIPSI, tempat_SKRIPSI, ruangan_SKRIPSI)
            VALUES ('$mhs_NPM', '$dosen_NIDN', '$waktu_SKRIPSI', '$tanggal_SKRIPSI', '$tempat_SKRIPSI', '$ruangan_SKRIPSI')
        ");

        echo "<script>location='inputjadwal.php';</script>";
    }
}
$q_mhs = mysqli_query($conn, "SELECT mhs_NPM, mhs_Nama FROM mahasiswa ORDER BY mhs_Nama ASC");
$q_dosen = mysqli_query($conn, "SELECT dosen_NIDN, dosen_Nama FROM dosen ORDER BY dosen_Nama ASC");
// QUERY DATA JADWAL + NAMA MHS + NAMA DOSEN
$query = mysqli_query($conn, "
    SELECT jadwalskripsi.*,
           mahasiswa.mhs_Nama,
           dosen.dosen_Nama
    FROM jadwalskripsi
    JOIN mahasiswa ON mahasiswa.mhs_NPM = jadwalskripsi.mhs_NPM
    JOIN dosen ON dosen.dosen_NIDN = jadwalskripsi.dosen_NIDN
    ORDER BY jadwalskripsi.tanggal_SKRIPSI ASC, jadwalskripsi.waktu_SKRIPSI ASC
");
?>

<!-- FORM INPUT -->
<div class="row">
<div class="col-1"></div>
<div class="col-10">

    <form method="POST">

        <div class="row mb-3 mt-4">
            <label class="col-sm-2 col-form-label">Mahasiswa</label>
            <div class="col-sm-10">
                <select class="form-select" id="npmMHS" name="npmMHS" required>
                    <option value="">-- Pilih Mahasiswa --</option>
                    <?php while($m = mysqli_fetch_assoc($q_mhs)) { ?>
                        <option value="<?= $m['mhs_NPM']; ?>">
                            <?= $m['mhs_Nama']; ?> (<?= $m['mhs_NPM']; ?>)
                        </option>
                    <?php } ?>
                </select>
            </div>
        </div>


                <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Dosen Pembimbing/Penguji</label>
            <div class="col-sm-10">
                <select class="form-select" id="nidnDOSEN" name="nidnDOSEN" required>
                    <option value="">-- Pilih Dosen --</option>
                    <?php while($d = mysqli_fetch_assoc($q_dosen)) { ?>
                        <option value="<?= $d['dosen_NIDN']; ?>">
                            <?= $d['dosen_Nama']; ?> (<?= $d['dosen_NIDN']; ?>)
                        </option>
                    <?php } ?>
                </select>
            </div>
        </div>


        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Tanggal Skripsi</label>
            <div class="col-sm-10">
                <input type="date" class="form-control"
                       id="tglSKRIPSI" name="tglSKRIPSI" required>
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Waktu Skripsi</label>
            <div class="col-sm-10">
                <input type="time" class="form-control"
                       id="waktuSKRIPSI" name="waktuSKRIPSI" required>
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Tempat</label>
            <div class="col-sm-10">
                <input type="text" class="form-control"
                       id="tempatSKRIPSI" name="tempatSKRIPSI" placeholder="Contoh: Kampus A, Gedung B">
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Ruangan</label>
            <div class="col-sm-10">
                <input type="text" class="form-control"
                       id="ruanganSKRIPSI" name="ruanganSKRIPSI" placeholder="Contoh: Ruang 201 / Lab 3">
            </div>
        </div>

        <div class="form-group row mb-4">
            <div class="col-sm-2"></div>
            <div class="col-sm-10">
                <button type="submit" class="btn btn-success" name="Simpan">Simpan</button>
                <button type="reset" class="btn btn-danger">Batal</button>
            </div>
        </div>

    </form>

</div>
<div class="col-1"></div>
</div>

<!-- TABEL JADWAL SKRIPSI -->
<div class="row mt-5">
<div class="col-1"></div>
<div class="col-10">

    <div class="jumbotron mb-3">
        <h3 class="display-6">Daftar Jadwal Skripsi</h3>
    </div>

    <table class="table table-striped table-success table-hover">
        <thead>
            <tr>
                <th>NPM</th>
                <th>Nama Mahasiswa</th>
                <th>NIDN</th>
                <th>Nama Dosen</th>
                <th>Tgl Skripsi</th>
                <th>Waktu</th>
                <th>Tempat</th>
                <th>Ruangan</th>
                <th style="text-align:center;">Aksi</th>
            </tr>
        </thead>

        <tbody>
        <?php while ($row = mysqli_fetch_array($query)) { ?>
            <tr>
                <td><?= $row['mhs_NPM']; ?></td>
                <td><?= $row['mhs_Nama']; ?></td>
                <td><?= $row['dosen_NIDN']; ?></td>
                <td><?= $row['dosen_Nama']; ?></td>
                <td><?= $row['tanggal_SKRIPSI']; ?></td>
                <td><?= $row['waktu_SKRIPSI']; ?></td>
                <td><?= $row['tempat_SKRIPSI']; ?></td>
                <td><?= $row['ruangan_SKRIPSI']; ?></td>

                <td style="text-align:center;">
                    <a href="editjadwal.php?npm=<?= $row['mhs_NPM']; ?>&nidn=<?= $row['dosen_NIDN']; ?>&tgl=<?= $row['tanggal_SKRIPSI']; ?>&waktu=<?= $row['waktu_SKRIPSI']; ?>"
                       class="btn btn-warning btn-sm">Edit</a>

                    <a href="hapusjadwal.php?hapusjadwal=<?= $row['mhs_NPM']; ?>"
                    class="btn btn-danger btn-sm"
                    onclick="return confirm('Yakin ingin menghapus?');">
                    Hapus
                    </a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>

</div>
<div class="col-1"></div>
</div>

</div>
</main>

<?php include "bagiankode/footer.php"; ?>

</div>
</div>

<?php include "bagiankode/footer.php"; ?>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>

</html>