<?php

include "includes/config.php"; 


if(isset($_GET['hapushasilakhir']))
{
  
    $NPM = $_GET["hapushasilakhir"]; 
    

    mysqli_query($conn, "DELETE FROM hasilakhir WHERE mhs_NPM = '$NPM'");
    
    
    echo "<script>alert('DATA BERHASIL DIHAPUS');";
    echo "document.location='inputhasilakhir.php'</script>";
}
?>