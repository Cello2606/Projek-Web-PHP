<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beranda Peserta Skripsi</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body>

<?php include("includes/frontmenu.php"); ?>

<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="images/zx6r2.jpg" class="d-block w-100" alt="No Picture">
        </div>
        <div class="carousel-item">
            <img src="images/zx6r2.jpg" class="d-block w-100" alt="No Picture">
        </div>
        <div class="carousel-item">
            <img src="images/zx6r2.jpg" class="d-block w-100" alt="No Picture">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>


<div class="container mt-4">

    <div class="row">
        <div class="col-lg-8">
            <h3 class="mb-3">Data Peserta Skripsi</h3>
            <?php 
            if(isset($conn)){
                $query = mysqli_query($conn, "SELECT * FROM pesertaskripsi");
                while ($row = mysqli_fetch_assoc($query)) : ?>
                <div class="card mb-4">
                    <div class="row g-0">
                        <div class="col-md-3">
                             <img src="images/<?php echo $row['peserta_DOKUMEN']; ?>" class="img-fluid rounded" alt="">
                        </div>
                        <div class="col-md-9">
                            <div class="card-body">
                                <h4><?php echo $row['peserta_JUDUL']; ?></h4>
                                <p class="mb-1">Semester: <b><?php echo $row['peserta_SEMT']; ?></b></p>
                                <p class="mb-1">Tanggal daftar: <b><?php echo $row['peserta_TGLDAFTAR']; ?></b></p>
                                <p>Nama Dokumen: <b><?php echo $row['peserta_DOKUMEN']; ?></b></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile; 
            } ?>
        </div> 

        <div class="col-lg-4">
            <div class="list-group">
                <a href="#" class="list-group-item list-group-item-action active" aria-current="true">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1">Kawasaki menang MOTO GP</h5>
                        <small>3 days ago</small>
                    </div>
                    <p class="mb-1">Jonathan Rea SANG JUARA MOTOGP.</p>
                    <small>Finish pada posisi ke 2 tetap juara.</small>
                </a>
                <a href="#" class="list-group-item list-group-item-action">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1">List group item heading</h5>
                        <small class="text-muted">3 days ago</small>
                    </div>
                    <p class="mb-1">Some placeholder content in a paragraph.</p>
                    <small class="text-muted">And some muted small print.</small>
                </a>
                <a href="#" class="list-group-item list-group-item-action">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1">List group item heading</h5>
                        <small class="text-muted">3 days ago</small>
                    </div>
                    <p class="mb-1">Some placeholder content in a paragraph.</p>
                    <small class="text-muted">And some muted small print.</small>
                </a>
            </div>
        </div> 
    </div> 

    <div class="row mt-5">
        <div class="col-md-4">
            <div class="border p-4 rounded text-center">
                <img src="images/z800.jpg" class="figure-img img-fluid rounded" alt="...">
                <h5>Kawasaki Z800</h5>
                <p>Inline 4 Cylinder, 800cc</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="border p-4 rounded text-center">
                <img src="images/KAWASAKIZX10R.png" class="figure-img img-fluid rounded" alt="...">
                <h5>Kawasaki ninja zx10r</h5>
                <p>Inline 4 Cylinder, 1000cc</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="border p-4 rounded text-center">
                <img src="images/ninja250.jpg" class="figure-img img-fluid rounded" alt="...">
                <h5>Kawasaki All Ninja 250</h5>
                <p>2 Cylinder, 249cc</p>
            </div>
        </div>
    </div>

    <div class="row tengah mt-5">
        
        <div class="col-md-4">
            <div class="card" style="width: 100%;">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">Kawasaki zx25r</li>
                    <li class="list-group-item">Kawasaki zx6r</li>
                    <li class="list-group-item">Kawasaki zx10r</li>
                </ul>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card h-100"> <div class="card-header">
                PESAN
                </div>
                <div class="card-body">
                    <figure>
                        <blockquote class="blockquote">
                            <p>Selalu berhati - hati dalam berkendara, SAFETTY FIRST.</p>
                        </blockquote>
                        <figcaption class="blockquote-footer">
                            Kenny Prasetya <cite title="Source Title">Source Info</cite>
                        </figcaption>
                    </figure>
                </div>
            </div>
        </div>

    </div>

    <div class="row mt-4">
        <div class="col-md-6">
            <figure class="figure w-100 text-center">
                <img src="images/zx25.webp" class="figure-img img-fluid rounded" alt="...">
                <figcaption class="figure-caption">Kawasaki ninja Zx25rr </figcaption>
            </figure>
        </div>

        <div class="col-md-6">
            <figure class="figure w-100 text-center">
                <img src="images/zx25.webp" class="figure-img img-fluid rounded" alt="...">
                <figcaption class="figure-caption">Kawasaki ninja Zx25rr</figcaption>
            </figure>
        </div>
    </div>
    
</div> 

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>