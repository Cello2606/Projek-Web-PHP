<?php
ob_start();
session_start();
if (!isset($_SESSION['useremail'])) {
    header("location:login.php");
    exit;
}

include("includes/config.php");

// ====================== AMBIL PARAMETER KUNCI DARI URL ======================
if (!isset($_GET['npm']) || !isset($_GET['nidn'])) {
    echo "<script>alert('Parameter tidak lengkap');location='inputhasilakhir.php';</script>";
    exit;
}

$npm_lama   = $_GET['npm'];
$nidn_lama  = $_GET['nidn'];

// ====================== AMBIL DATA HASIL AKHIR YANG MAU DIEDIT ======================
$q_hasil = mysqli_query($conn, "
    SELECT *
    FROM hasilakhir
    WHERE mhs_NPM = '$npm_lama'
      AND dosen_NIDN = '$nidn_lama'
");

$data_hasil = mysqli_fetch_assoc($q_hasil);

if (!$data_hasil) {
    echo "<script>alert('Data hasil akhir tidak ditemukan');location='inputhasilakhir.php';</script>";
    exit;
}

// ====================== DATA UNTUK DROPDOWN ======================
$datamhs   = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY mhs_Nama ASC");
$datadosen = mysqli_query($conn, "SELECT * FROM dosen ORDER BY dosen_Nama ASC");

// ====================== PROSES UPDATE ======================
if (isset($_POST['update'])) {

    $mhs_NPM_baru         = $_POST['npmMHS'];
    $dosen_NIDN_baru      = $_POST['nidnDOSEN'];
    $ISI_bimbingan_baru   = $_POST['isiBIMBINGAN'];
    $peserta_JUDUL_baru   = $_POST['judulSKRIPSI'];
    $TGL_ujian_baru       = $_POST['tglUjian'];
    $tanggal_SKRIPSI_baru = $_POST['tglSkripsi'];
    $statusakhir_baru     = $_POST['statusakhir'];

    if (empty($mhs_NPM_baru) || empty($dosen_NIDN_baru) || empty($statusakhir_baru)) {
        echo "<script>alert('NPM, Dosen, dan Status Akhir wajib diisi');</script>";
    } else {

        mysqli_query($conn, "
            UPDATE hasilakhir SET
                mhs_NPM         = '$mhs_NPM_baru',
                dosen_NIDN      = '$dosen_NIDN_baru',
                ISI_bimbingan   = '$ISI_bimbingan_baru',
                peserta_JUDUL   = '$peserta_JUDUL_baru',
                TGL_ujian       = '$TGL_ujian_baru',
                tanggal_SKRIPSI = '$tanggal_SKRIPSI_baru',
                statusakhir     = '$statusakhir_baru'
            WHERE mhs_NPM    = '$npm_lama'
              AND dosen_NIDN = '$nidn_lama'
        ");

        echo "<script>alert('Data hasil akhir skripsi berhasil diupdate');location='inputhasilakhir.php';</script>";
        exit;
    }
}

// ====================== DATA UNTUK TABEL DI BAWAH ======================
$query = mysqli_query($conn, "
    SELECT 
        hasilakhir.mhs_NPM,
        mahasiswa.mhs_Nama,
        hasilakhir.dosen_NIDN,
        dosen.dosen_Nama,
        hasilakhir.ISI_bimbingan,
        hasilakhir.peserta_JUDUL,
        hasilakhir.TGL_ujian,
        hasilakhir.tanggal_SKRIPSI,
        hasilakhir.statusakhir
    FROM hasilakhir
    JOIN mahasiswa ON hasilakhir.mhs_NPM = mahasiswa.mhs_NPM
    JOIN dosen ON hasilakhir.dosen_NIDN = dosen.dosen_NIDN
    ORDER BY hasilakhir.TGL_ujian ASC
");
?>

<!DOCTYPE html>
<html>
    <?php
    include "bagiankode/head.php";
    ?>
<body class="sb-nav-fixed">
<?php
include "bagiankode/menunav.php";
?>
<div id="layoutSidenav">
    <?php
    include "bagiankode/menu.php";
    ?>

    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">

                <h1 class="mt-4">Edit Hasil Akhir Skripsi</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="inputhasilakhir.php">Hasil Akhir Skripsi</a></li>
                    <li class="breadcrumb-item active">Edit Hasil Akhir Skripsi</li>
                </ol>

                <!-- FORM EDIT -->
                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-10">

                        <form method="POST" class="mb-4">

                            <!-- simpan kunci lama -->
                            <input type="hidden" name="npm_lama"  value="<?= $npm_lama; ?>">
                            <input type="hidden" name="nidn_lama" value="<?= $nidn_lama; ?>">

                            <div class="row mb-3 mt-4">
                                <label class="col-sm-2 col-form-label">NPM Mahasiswa</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="npmMHS" name="npmMHS" required>
                                        <option value="">-- Pilih Mahasiswa --</option>
                                        <?php
                                        // karena $datamhs sudah pernah di-loop di atas, kita reset query lagi
                                        $datamhs2 = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY mhs_Nama ASC");
                                        while ($m = mysqli_fetch_array($datamhs2)) { ?>
                                            <option value="<?= $m['mhs_NPM']; ?>"
                                                <?= ($m['mhs_NPM'] == $data_hasil['mhs_NPM']) ? 'selected' : ''; ?>>
                                                <?= $m['mhs_NPM']; ?> - <?= $m['mhs_Nama']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">NIDN Dosen</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="nidnDOSEN" name="nidnDOSEN" required>
                                        <option value="">-- Pilih Dosen --</option>
                                        <?php
                                        $datadosen2 = mysqli_query($conn, "SELECT * FROM dosen ORDER BY dosen_Nama ASC");
                                        while ($d = mysqli_fetch_array($datadosen2)) { ?>
                                            <option value="<?= $d['dosen_NIDN']; ?>"
                                                <?= ($d['dosen_NIDN'] == $data_hasil['dosen_NIDN']) ? 'selected' : ''; ?>>
                                                <?= $d['dosen_NIDN']; ?> - <?= $d['dosen_Nama']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Isi Bimbingan</label>
                                <div class="col-sm-10">
                                    <textarea class="form-control" id="isiBIMBINGAN" name="isiBIMBINGAN" rows="3"
                                              placeholder="Ringkasan isi bimbingan terakhir / kesimpulan"><?= $data_hasil['ISI_bimbingan']; ?></textarea>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Judul Skripsi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control"
                                           id="judulSKRIPSI" name="judulSKRIPSI"
                                           value="<?= $data_hasil['peserta_JUDUL']; ?>"
                                           placeholder="Judul Skripsi">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Tgl Ujian</label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control"
                                           id="tglUjian" name="tglUjian"
                                           value="<?= $data_hasil['TGL_ujian']; ?>">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Tgl Skripsi</label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control"
                                           id="tglSkripsi" name="tglSkripsi"
                                           value="<?= $data_hasil['tanggal_SKRIPSI']; ?>">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Status Akhir</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control"
                                           id="statusakhir" name="statusakhir"
                                           value="<?= $data_hasil['statusakhir']; ?>"
                                           placeholder="Contoh: Lulus, Tidak Lulus, Revisi, dll" required>
                                </div>
                            </div>

                            <div class="form-group row mb-4">
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-success" name="update">Simpan Perubahan</button>
                                    <a href="inputhasilakhir.php" class="btn btn-secondary">Kembali</a>
                                </div>
                            </div>

                        </form>

                    </div>
                    <div class="col-1"></div>
                </div>

                <!-- TABEL HASIL AKHIR -->
<div class="row mt-5">
<div class="col-1"></div>
<div class="col-10">

    <div class="jumbotron mb-3">
        <h3 class="display-6">Daftar Hasil Akhir Skripsi</h3>
    </div>

    <table class="table table-striped table-success table-hover">
        <thead>
            <tr>
                <th>NPM</th>
                <th>Nama Mahasiswa</th>
                <th>Dosen NIDN</th>
                <th>Nama Dosen</th>
                <th>Isi Bimbingan</th>
                <th>Judul Skripsi</th>
                <th>Tgl Ujian</th>
                <th>Tgl Skripsi</th>
                <th>Status Akhir</th>
                <th style="text-align:center;">Aksi</th>
            </tr>
        </thead>

        <tbody>
        <?php while ($row = mysqli_fetch_array($query)) { ?>
            <tr>
                <td><?= $row['mhs_NPM']; ?></td>
                <td><?= $row['mhs_Nama']; ?></td>
                <td><?= $row['dosen_NIDN']; ?></td>
                <td><?= $row['dosen_Nama']; ?></td>
                <td><?= $row['ISI_bimbingan']; ?></td>
                <td><?= $row['peserta_JUDUL']; ?></td>
                <td><?= $row['TGL_ujian']; ?></td>
                <td><?= $row['tanggal_SKRIPSI']; ?></td>
                <td><?= $row['statusakhir']; ?></td>

                <td class="text-center">
                    <div class="btn-group" role="group" aria-label="Aksi">
                        <a href="edithasilakhir.php?npm=<?= $row['mhs_NPM']; ?>&nidn=<?= $row['dosen_NIDN']; ?>"
                           class="btn btn-warning btn-sm">
                            Edit
                        </a>
                        <a href="hapushasilakhir.php?hapushasilakhir=<?= $row['mhs_NPM']; ?>&nidn=<?= $row['dosen_NIDN']; ?>"
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Yakin ingin menghapus?');">
                            Hapus
                        </a>
                    </div>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>

</div>
<div class="col-1"></div>
</div>
            </div>
        </main>

        <?php include "bagiankode/footer.php"; ?>

    </div>
</div>

<?php include "bagiankode/jsscript.php"; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>