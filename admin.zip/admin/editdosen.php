<?php
ob_start();
session_start();
if (!isset($_SESSION['useremail'])) {
    header("location:login.php");
    exit;
}

include("includes/config.php");

// AMBIL NIDN DARI URL
if (!isset($_GET['nidn'])) {
    echo "<script>alert('Parameter NIDN tidak ditemukan');location='inputdosen.php';</script>";
    exit;
}

$nidn = $_GET["nidn"];

// CEK DATA DOSEN
$q_dosen = mysqli_query($conn, "SELECT * FROM dosen WHERE dosen_NIDN = '$nidn'");
$row = mysqli_fetch_assoc($q_dosen);

if (!$row) {
    echo "<script>alert('Data dosen tidak ditemukan');location='inputdosen.php';</script>";
    exit;
}

// PROSES UPDATE
if (isset($_POST['update'])) {

    $newNIDN = $_POST['dosen_NIDN'];
    $newNIK  = $_POST['nikDSN'];
    $newNama = $_POST['namaDSN'];
    $newKet  = $_POST['ketDSN'];

    mysqli_query($conn, "
        UPDATE dosen SET 
            dosen_NIDN = '$newNIDN',
            dosen_NIK  = '$newNIK',
            dosen_Nama = '$newNama',
            dosen_Ket  = '$newKet'
        WHERE dosen_NIDN = '$nidn'
    ");

    echo "<script>alert('Data dosen berhasil diperbarui');location='inputdosen.php';</script>";
    exit;
}

// QUERY DATA UNTUK TABEL DI BAWAH
$query = mysqli_query($conn, "SELECT * FROM dosen ORDER BY dosen_NIDN ASC");
?>

<!DOCTYPE html>
<html>
    <?php include "bagiankode/head.php"; ?>
<body class="sb-nav-fixed">

<?php include "bagiankode/menunav.php"; ?>

<div id="layoutSidenav">

    <?php include "bagiankode/menu.php"; ?>

    <div id="layoutSidenav_content">
        <main>

            <div class="container-fluid px-4">

                <h1 class="mt-4">Edit Dosen</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="inputdosen.php">Dosen</a></li>
                    <li class="breadcrumb-item active">Edit Dosen</li>
                </ol>

                <!-- FORM EDIT DOSEN -->
                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-10">

                        <div class="card mb-4">
                            <div class="card-header bg-warning text-white">
                                Form Edit Dosen
                            </div>

                            <div class="card-body">
                                <form method="POST">

                                    <!-- NIDN -->
                                    <div class="row mb-3">
                                        <label class="col-sm-2 col-form-label">NIDN Dosen</label>
                                        <div class="col-sm-10">
                                            <input type="text" name="dosen_NIDN" class="form-control"
                                                value="<?= $row['dosen_NIDN']; ?>" required maxlength="9">
                                        </div>
                                    </div>

                                    <!-- NIK -->
                                    <div class="row mb-3">
                                        <label class="col-sm-2 col-form-label">NIK Dosen</label>
                                        <div class="col-sm-10">
                                            <input type="text" name="nikDSN" class="form-control"
                                                value="<?= $row['dosen_NIK']; ?>" required>
                                        </div>
                                    </div>

                                    <!-- NAMA -->
                                    <div class="row mb-3">
                                        <label class="col-sm-2 col-form-label">Nama Dosen</label>
                                        <div class="col-sm-10">
                                            <input type="text" name="namaDSN" class="form-control"
                                                value="<?= $row['dosen_Nama']; ?>" required>
                                        </div>
                                    </div>

                                    <!-- KETERANGAN -->
                                    <div class="row mb-3">
                                        <label class="col-sm-2 col-form-label">Keterangan</label>
                                        <div class="col-sm-10">
                                            <input type="text" name="ketDSN" class="form-control"
                                                value="<?= $row['dosen_Ket']; ?>">
                                        </div>
                                    </div>

                                    <!-- BUTTON -->
                                    <div class="form-group row">
                                        <div class="col-sm-2"></div>
                                        <div class="col-sm-10">
                                            <button class="btn btn-success" name="update">Update</button>
                                            <a href="inputdosen.php" class="btn btn-secondary">Kembali</a>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>

                    </div>
                    <div class="col-1"></div>
                </div>

                <!-- TABEL DOSEN -->
                <div class="row mt-3">
                    <div class="col-1"></div>
                    <div class="col-10">

                        <div class="jumbotron mb-3">
                            <h3 class="display-6">Daftar Dosen</h3>
                        </div>

                        <table class="table table-striped table-success table-hover">
                            <thead>
                                <tr>
                                    <th>NIDN</th>
                                    <th>NIK</th>
                                    <th>Nama Dosen</th>
                                    <th>Keterangan</th>
                                    <th style="text-align:center;">Aksi</th>
                                </tr>
                            </thead>

                            <tbody>
                            <?php while ($d = mysqli_fetch_array($query)) { ?>
                                <tr>
                                    <td><?= $d['dosen_NIDN']; ?></td>
                                    <td><?= $d['dosen_NIK']; ?></td>
                                    <td><?= $d['dosen_Nama']; ?></td>
                                    <td><?= $d['dosen_Ket']; ?></td>

                                    <td style="text-align:center;">
                                        <div class="btn-group" role="group" aria-label="Aksi">
                                            <a href="editdosen.php?nidn=<?= $d['dosen_NIDN']; ?>"
                                               class="btn btn-warning btn-sm">Edit</a>

                                            <a href="hapusdosen.php?nidn=<?= $d['dosen_NIDN']; ?>"
                                               class="btn btn-danger btn-sm"
                                               onclick="return confirm('Yakin ingin menghapus?');">
                                                Hapus
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>

                    </div>
                    <div class="col-1"></div>
                </div>

            </div>

        </main>

        <?php include "bagiankode/footer.php"; ?>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>