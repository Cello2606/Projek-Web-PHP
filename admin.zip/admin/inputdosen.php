<!DOCTYPE html>
<html>
    <?php
include "bagiankode/head.php";
?>
<?php
ob_start();
session_start();
if(!isset($_SESSION['useremail']))
header("location:login.php");
?>
<body class="sb-nav-fixed">
<?php
include "bagiankode/menunav.php";
?>
    <div id="layoutSidenav">
        <?php
include "bagiankode/menu.php";
?>

<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">

    <h1 class="mt-4">Input Dosen</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dosen</li>
    </ol>

<?php
include("includes/config.php");
// ====================== SIMPAN DATA ======================
if (isset($_POST['Simpan'])) {

    $nidn = $_POST['dosen_NIDN'];
    $nik  = $_POST['nikDSN'];
    $nama = $_POST['namaDSN'];
    $ket  = $_POST['ketDSN'];

    if (empty($nidn) || empty($nik) || empty($nama)) {
        echo "<script>alert('Harap isi semua data wajib!');</script>";
    } else {
        mysqli_query($conn, "
            INSERT INTO dosen (dosen_NIDN, dosen_NIK, dosen_Nama, dosen_Ket)
            VALUES ('$nidn', '$nik', '$nama', '$ket')
        ");

        echo "<script>alert('Data dosen berhasil ditambahkan');location='inputdosen.php';</script>";
        exit;
    }
}

// ====================== AMBIL DATA DOSEN ======================
$query = mysqli_query($conn, "SELECT * FROM dosen ORDER BY dosen_Nama ASC");
?>

    <!-- ================= FORM INPUT ================= -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            Tambah Dosen
        </div>

        <div class="card-body">

        <form method="POST">

            <div class="mb-3">
                <label>NIDN Dosen</label>
                <input type="text" class="form-control" name="dosen_NIDN"
                       placeholder="Nomor Induk Dosen" maxlength="10" required>
            </div>

            <div class="mb-3">
                <label>NIK Dosen</label>
                <input type="text" class="form-control" name="nikDSN"
                       placeholder="Masukkan NIK" required>
            </div>

            <div class="mb-3">
                <label>Nama Dosen</label>
                <input type="text" class="form-control" name="namaDSN"
                       placeholder="Isikan Nama Dosen" required>
            </div>

            <div class="mb-3">
                <label>Keterangan</label>
                <input type="text" class="form-control" name="ketDSN"
                       placeholder="Tulis keterangan (opsional)">
            </div>

            <button class="btn btn-success" name="Simpan">Simpan</button>
            <button class="btn btn-danger" type="reset">Batal</button>

        </form>

        </div>
    </div>


    <!-- ================= TABEL DATA DOSEN ================= -->
    <div class="card mb-4">
        <div class="card-header bg-dark text-white">
            Daftar Dosen
        </div>

        <div class="card-body">

        <table class="table table-bordered table-striped">
            <thead class="table-success">
                <tr>
                    <th>NIDN</th>
                    <th>NIK</th>
                    <th>Nama Dosen</th>
                    <th>Keterangan</th>
                    <th width="150px">Aksi</th>
                </tr>
            </thead>

            <tbody>
            <?php while ($row = mysqli_fetch_assoc($query)) { ?>
                <tr>
                    <td><?= $row['dosen_NIDN']; ?></td>
                    <td><?= $row['dosen_NIK']; ?></td>
                    <td><?= $row['dosen_Nama']; ?></td>
                    <td><?= $row['dosen_Ket']; ?></td>

                    <td>
                        <a href="editdosen.php?nidn=<?= $row['dosen_NIDN']; ?>"
                           class="btn btn-warning btn-sm">Edit</a>

                        <a href="hapusdosen.php?nidn=<?= $row['dosen_NIDN']; ?>"
                           onclick="return confirm('Hapus dosen ini?');"
                           class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>

        </table>

        </div>
    </div>

</div>
</main>

<?php include "bagiankode/footer.php"; ?>

</div>
</div>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</html>
