<!DOCTYPE html>
<html>
    <?php
include "bagiankode/head.php";
?>
<?php
ob_start();
session_start();
if(!isset($_SESSION['useremail']))
header("location:login.php");
?>
<body class="sb-nav-fixed">
<?php
include "bagiankode/menunav.php";
?>
    <div id="layoutSidenav">
        <?php
include "bagiankode/menu.php";
?>

<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">

    <h1 class="mt-4">Input Hasil Akhir Skripsi</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Hasil Akhir Skripsi</li>
    </ol>

<?php
include("includes/config.php");

// AMBIL DATA UNTUK DROPDOWN
$datamhs   = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY mhs_Nama ASC");
$datadosen = mysqli_query($conn, "SELECT * FROM dosen ORDER BY dosen_Nama ASC");

// PROSES SIMPAN (hasilakhir) TANPA JOIN
if (isset($_POST['Simpan'])) {

    $mhs_NPM         = $_POST['npmMHS'];
    $dosen_NIDN      = $_POST['nidnDOSEN'];
    $ISI_bimbingan   = $_POST['isiBIMBINGAN'];
    $peserta_JUDUL   = $_POST['judulSKRIPSI'];
    $TGL_ujian       = $_POST['tglUjian'];
    $tanggal_SKRIPSI = $_POST['tglSkripsi'];
    $statusakhir     = $_POST['statusakhir'];

    // Validasi minimal input
    if (empty($mhs_NPM) || empty($dosen_NIDN) || empty($statusakhir)) {
        echo "<script>alert('NPM, Dosen, dan Status Akhir wajib diisi');</script>";
    } else {

        mysqli_query($conn, "
            INSERT INTO hasilakhir
            (mhs_NPM, dosen_NIDN, ISI_bimbingan, peserta_JUDUL, TGL_ujian, tanggal_SKRIPSI, statusakhir)
            VALUES ('$mhs_NPM', '$dosen_NIDN', '$ISI_bimbingan', '$peserta_JUDUL', '$TGL_ujian', '$tanggal_SKRIPSI', '$statusakhir')
        ");

        echo "<script>location='inputhasilakhir.php';</script>";
    }
}

// QUERY DATA HASIL AKHIR TANPA JOIN
$query = mysqli_query($conn, "
    SELECT 
        hasilakhir.mhs_NPM,
        mahasiswa.mhs_Nama,
        hasilakhir.dosen_NIDN,
        dosen.dosen_Nama,
        hasilakhir.ISI_bimbingan,
        hasilakhir.peserta_JUDUL,
        hasilakhir.TGL_ujian,
        hasilakhir.tanggal_SKRIPSI,
        hasilakhir.statusakhir
    FROM hasilakhir
    JOIN mahasiswa ON hasilakhir.mhs_NPM = mahasiswa.mhs_NPM
    JOIN dosen ON hasilakhir.dosen_NIDN = dosen.dosen_NIDN
    ORDER BY hasilakhir.TGL_ujian ASC
");

?>

<!-- FORM INPUT -->
<div class="row">
<div class="col-1"></div>
<div class="col-10">

    <form method="POST">

        <div class="row mb-3 mt-4">
            <label class="col-sm-2 col-form-label">NPM Mahasiswa</label>
            <div class="col-sm-10">
                <select class="form-control" id="npmMHS" name="npmMHS" required>
                    <option value="">-- Pilih Mahasiswa --</option>
                    <?php while ($m = mysqli_fetch_array($datamhs)) { ?>
                        <option value="<?= $m['mhs_NPM']; ?>">
                            <?= $m['mhs_NPM']; ?> - <?= $m['mhs_Nama']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">NIDN Dosen</label>
            <div class="col-sm-10">
                <select class="form-control" id="nidnDOSEN" name="nidnDOSEN" required>
                    <option value="">-- Pilih Dosen --</option>
                    <?php while ($d = mysqli_fetch_array($datadosen)) { ?>
                        <option value="<?= $d['dosen_NIDN']; ?>">
                            <?= $d['dosen_NIDN']; ?> - <?= $d['dosen_Nama']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Isi Bimbingan</label>
            <div class="col-sm-10">
                <textarea class="form-control" id="isiBIMBINGAN" name="isiBIMBINGAN" rows="3" placeholder="Ringkasan isi bimbingan terakhir / kesimpulan"></textarea>
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Judul Skripsi</label>
            <div class="col-sm-10">
                <input type="text" class="form-control"
                       id="judulSKRIPSI" name="judulSKRIPSI" placeholder="Judul Skripsi">
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Tgl Ujian</label>
            <div class="col-sm-10">
                <input type="date" class="form-control"
                       id="tglUjian" name="tglUjian">
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Tgl Skripsi</label>
            <div class="col-sm-10">
                <input type="date" class="form-control"
                       id="tglSkripsi" name="tglSkripsi">
            </div>
        </div>

        <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Status Akhir</label>
            <div class="col-sm-10">
                <input type="text" class="form-control"
                       id="statusakhir" name="statusakhir" placeholder="Contoh: Lulus, Tidak Lulus, Revisi, dll" required>
            </div>
        </div>

        <div class="form-group row mb-4">
            <div class="col-sm-2"></div>
            <div class="col-sm-10">
                <button type="submit" class="btn btn-success" name="Simpan">Simpan</button>
                <button type="reset" class="btn btn-danger">Batal</button>
            </div>
        </div>

    </form>

</div>
<div class="col-1"></div>
</div>

<!-- TABEL HASIL AKHIR -->
<div class="row mt-5">
<div class="col-1"></div>
<div class="col-10">

    <div class="jumbotron mb-3">
        <h3 class="display-6">Daftar Hasil Akhir Skripsi</h3>
    </div>

    <table class="table table-striped table-success table-hover">
        <thead>
            <tr>
                <th>NPM</th>
                <th>Nama Mahasiswa</th>
                <th>Dosen NIDN</th>
                <th>Nama Dosen</th>
                <th>Isi Bimbingan</th>
                <th>Judul Skripsi</th>
                <th>Tgl Ujian</th>
                <th>Tgl Skripsi</th>
                <th>Status Akhir</th>
                <th style="text-align:center;">Aksi</th>
            </tr>
        </thead>

        <tbody>
        <?php while ($row = mysqli_fetch_array($query)) { ?>
            <tr>
                <td><?= $row['mhs_NPM']; ?></td>
                <td><?= $row['mhs_Nama']; ?></td>
                <td><?= $row['dosen_NIDN']; ?></td>
                <td><?= $row['dosen_Nama']; ?></td>
                <td><?= $row['ISI_bimbingan']; ?></td>
                <td><?= $row['peserta_JUDUL']; ?></td>
                <td><?= $row['TGL_ujian']; ?></td>
                <td><?= $row['tanggal_SKRIPSI']; ?></td>
                <td><?= $row['statusakhir']; ?></td>

                <td class="text-center">
                    <div class="btn-group" role="group" aria-label="Aksi">
                        <a href="edithasilakhir.php?npm=<?= $row['mhs_NPM']; ?>&nidn=<?= $row['dosen_NIDN']; ?>"
                           class="btn btn-warning btn-sm">
                            Edit
                        </a>
                        <a href="inputhasilakhir.php?hapushasilakhir=<?= $row['mhs_NPM']; ?>&nidn=<?= $row['dosen_NIDN']; ?>"
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Yakin ingin menghapus?');">
                            Hapus
                        </a>
                    </div>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>

</div>
<div class="col-1"></div>
</div>

</div>
</main>

<?php include "bagiankode/footer.php"; ?>

</div>
</div>

<?php include "bagiankode/footer.php"; ?>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>

</html>